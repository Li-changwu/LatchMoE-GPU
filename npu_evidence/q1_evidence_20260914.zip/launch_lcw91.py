"""Start an authorized finite campaign independently of the SSH connection."""
import argparse
import json
import subprocess
import sys
import time
from run_job import ROOT,save
from campaign_lcw91 import qualification
p=argparse.ArgumentParser();p.add_argument('--model',choices=['qwen','glm'],required=True)
model=p.parse_args().model
assert any('lcw91' in x for x in qualification(model)), 'New-host qualification missing'
target=ROOT/f'campaign_lcw91_{model}_launcher.json'
if target.exists():
    old=json.loads(target.read_text());proc=__import__('pathlib').Path(f"/proc/{old['pid']}/cmdline")
    if proc.exists() and b'campaign_lcw91.py' in proc.read_bytes():
        raise SystemExit('Campaign already running: '+str(old['pid']))
cmd=[sys.executable,str(ROOT/'campaign_lcw91.py'),'--model',model]
with (ROOT/f'campaign_lcw91_{model}.log').open('a') as log:
    process=subprocess.Popen(cmd,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
save(target,{'pid':process.pid,'command':cmd,'launched_unix':time.time(),'host':'lcw-91'})
print(json.dumps({'model':model,'pid':process.pid,'status':'launched'}))
