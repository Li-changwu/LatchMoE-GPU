"""Standalone Q1 figures from validated results, preserving existing paper figures."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parent
data=json.loads((root/'analysis.json').read_text())
if not data['valid']:
    raise SystemExit('Q1 validation is incomplete; publication figures were not generated')
rows={(r['model'],r['dataset'],r['arm']):r for r in data['units']}
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'svg.fonttype':'none'})
models=[('qwen','Qwen3-30B-A3B'),('glm','GLM-4.7-Flash')]
datasets=['sharegpt','humaneval','gsm8k'];labels=['ShareGPT','HumanEval','GSM8K']
arms=[('eager','Cache-Offload Eager','#808A96'),('native','Native-Prefetch','#3B78A4'),
      ('latchmoe','LatchMoE','#D17A22')]

def panel(ax,model,key,scale,title,ylabel):
    x=np.arange(3);width=.24
    for i,(arm,label,color) in enumerate(arms):
        y=[rows[model,d,arm][key]*scale for d in datasets]
        ax.bar(x+(i-1)*width,y,width,color=color,label=label,zorder=3)
    ax.set_xticks(x,labels);ax.set_ylim(bottom=0)
    ax.set_title(title,fontsize=11);ax.set_ylabel(ylabel)
    ax.grid(axis='y',alpha=.18,zorder=0)

fig,axs=plt.subplots(2,3,figsize=(11.5,6))
for i,(model,title) in enumerate(models):
    for j,(key,scale,metric,ylabel) in enumerate([
        ('output_throughput_tok_s',1,'Output throughput ↑','tokens / s'),
        ('ttft_ms_p50',.001,'Median TTFT ↓','seconds'),
        ('tpot_ms_p50',1,'Median TPOT ↓','ms / token')]):
        panel(axs[i,j],model,key,scale,title+' · '+metric,ylabel)
handles,legend=axs[0,0].get_legend_handles_labels()
fig.legend(handles,legend,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.02))
fig.text(.5,.01,'20 prompts · cap 128 · EOS allowed · one selected complete run/configuration\nShareGPT: original host; HumanEval/GSM8K: lcw-91. Comparisons matched within each host.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.05,1,.96))
for ext in ('pdf','svg','png'): fig.savefig(root/f'eval_q1_serving_rerun.{ext}',dpi=200,bbox_inches='tight')
plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(8.5,4.0))
for ax,(model,title) in zip(axs,models):
    panel(ax,model,'request_call_ms_p50',.001,title,'Median complete request latency (s)')
fig.legend(handles,legend,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.06))
fig.text(.5,.01,'20 prompts · cap 128 · EOS allowed · one selected complete run/configuration\nShareGPT: original host; HumanEval/GSM8K: lcw-91. Comparisons matched within each host.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.08,1,.94))
for ext in ('pdf','svg','png'): fig.savefig(root/f'eval_q1_request_latency.{ext}',dpi=200,bbox_inches='tight')
print('Wrote validated Q1 serving and complete-request-latency figures (PDF, SVG, PNG).')
