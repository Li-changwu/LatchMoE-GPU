"""Record installed runtime revisions without modifying the runtime."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
snapshot={'checked_utc':datetime.now(timezone.utc).isoformat(),'repositories':{}}
for name in ('vllm-hust','vllm-ascend-hust'):
    p=Path('/workspace/latchmoe-locked-stack')/name
    def git(*args): return subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
    snapshot['repositories'][name]={'path':str(p),'head':git('rev-parse','HEAD'),
                                   'status_porcelain':git('status','--porcelain')}
destination=root/('stack_snapshot_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')
destination.write_text(json.dumps(snapshot,indent=2)+'\n')
print(json.dumps(snapshot))
