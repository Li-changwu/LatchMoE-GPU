"""Read-only resource samples alongside finite Q1 experiments, never in workers."""
import datetime
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/latchmoe-q1-rerun-20260914')
def command(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=25)
    return {'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}

def main():
    now = datetime.datetime.now(datetime.timezone.utc)
    sample = {'utc': now.isoformat(), 'unix': time.time(), 'host': 'lcw-91',
              'loadavg': Path('/proc/loadavg').read_text(),
              'npu': command(['npu-smi', 'info']),
              'processes': command(['ps', '-eo', 'pid,ppid,pcpu,pmem,comm', '--sort=-pcpu']),
              'cpu_stat': Path('/proc/stat').read_text(),
              'pressure': {k: Path('/proc/pressure', k).read_text() for k in ('cpu','memory','io')},
              'numa': {str(n): Path(f'/sys/devices/system/node/node{n}/numastat').read_text()
                       for n in (2,4)}}
    out = ROOT / 'resource_samples'
    out.mkdir(exist_ok=True)
    path = out / (now.strftime('%Y%m%dT%H%M%S%fZ') + '.json')
    path.write_text(json.dumps(sample, indent=2) + '\n')
    print(json.dumps({'utc': sample['utc'], 'path': str(path), 'loadavg': sample['loadavg'].strip()}))

if __name__ == '__main__':
    main()
