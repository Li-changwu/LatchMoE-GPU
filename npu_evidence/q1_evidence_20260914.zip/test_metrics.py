"""Exercise only the timing functions, without importing an accelerator stack."""
import ast
import math
from pathlib import Path
import statistics
from types import SimpleNamespace as S
from typing import Any

path=Path(__file__).with_name('runner.py')
tree=ast.parse(path.read_text(encoding='utf-8'))
names={'_metrics_from_outputs','_summarize','_percentile'}
defs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
scope={'math':math,'statistics':statistics,'Any':Any}
exec(compile(ast.Module(body=defs,type_ignores=[]),str(path),'exec'),scope)
measure=scope['_metrics_from_outputs']
def out(n=3,metric=None):
    return S(outputs=[S(token_ids=list(range(n)))],request_id='0',metrics=metric)
m=measure([out(metric=S(first_token_latency=.1,first_token_ts=3.,last_token_ts=3.4))],.51)
r=m['per_request'][0]
assert abs(r['ttft_ms']-100)<1e-9 and abs(r['tpot_ms']-200)<1e-9
assert abs(r['request_stream_ms']-500)<1e-9
m=measure([out(n=1,metric=S(first_token_latency=.1))],.11)
assert m['tpot_ms'] is None and m['per_request'][0]['tpot_ms'] is None
bad=[None,S(first_token_latency=float('nan')),S(first_token_latency=0),
     S(first_token_latency=.1),S(first_token_latency=.1,first_token_ts=3.,last_token_ts=2.),
     S(first_token_latency=.1,first_token_ts=3.,last_token_ts=float('inf'))]
for metric in bad:
    try: measure([out(metric=metric)],1.)
    except (ValueError,TypeError): pass
    else: raise AssertionError('invalid metrics accepted')
print('{"status":"passed","cases":8,"accelerator_initialized":false}')
