"""Resume missing complete units after migration; never reuse truncated runs."""
import argparse
import fcntl
import json
from run_job import ROOT,run,save
from campaign import qualification

def lane(model):
    gates=[p for p in qualification(model)
           if json.loads((ROOT/'runs'/p.split('/')[-1]/'unit.json').read_text()).get('execution_host')=='lcw-91']
    if not gates:
        raise RuntimeError('No successful qualification on lcw-91 for '+model)
    save(ROOT/f'campaign_lcw91_{model}_gate.json',gates)
    results=[]
    for dataset,arms in [('humaneval',('native','latchmoe','eager')),
                         ('gsm8k',('eager','native','latchmoe'))]:
        for arm in arms:
            name=f'{model}_{dataset}_{arm}_lcw91_r1'
            prior=ROOT/'runs'/name/'unit.json'
            if prior.exists():
                unit=json.loads(prior.read_text())
                if unit['status']!='complete':
                    raise RuntimeError('Existing incomplete unit preserved: '+name)
            else:
                unit=run({'name':name,'model':model,'dataset':dataset,'arm':arm,'requests':20,'verify':False})
            results.append(unit)
            save(ROOT/f'campaign_lcw91_{model}_progress.json',results)
            if unit['status']!='complete':
                raise RuntimeError('Failed unit; lane stopped: '+name)
    save(ROOT/f'campaign_lcw91_{model}_complete.json',{'status':'complete','results':results})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',choices=['qwen','glm'],required=True)
    model=p.parse_args().model
    with (ROOT/f'campaign_lcw91_{model}.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        lane(model)
