"""Audit the predeclared complete repeat without dropping slow requests."""
import csv
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
NAMES = ('glm_humaneval_native_lcw91_r1', 'glm_humaneval_native_lcw91_stability_r1')

def read(p):
    return json.loads(p.read_text(encoding='utf-8'))

def records(p):
    with p.open(encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]

def audit(root):
    dirs = [root/'runs'/n for n in NAMES]
    units = [read(d/'unit.json') for d in dirs]
    summaries = [read(d/'summary.json') for d in dirs]
    outputs = [records(d/'outputs.jsonl') for d in dirs]
    for u, s in zip(units, summaries):
        assert u['status']=='complete' and u['exit_code']==0 and not u['verify']
        assert (u['model'],u['dataset'],u['arm'],u['execution_host'],u['device'],u['numa_node']) == (
            'glm','humaneval','native','lcw-91',7,2)
        assert s['status']=='ok' and s['completed']==20
    assert units[0]['manifest_sha256']==units[1]['manifest_sha256']
    for rel, h in units[0]['source_hashes'].items():
        if rel in ('runner.py','wave_executor.py','wave_worker.py') or rel.startswith('overlay/'):
            assert units[1]['source_hashes'][rel]==h, 'Core source changed: '+rel
    normalized = []
    for u in units:
        cmd = u['command'][:]
        cmd[cmd.index('--output-dir')+1] = '<OUTPUT>'
        normalized.append(cmd)
    assert normalized[0]==normalized[1], 'Execution command changed beyond output directory'
    assert units[0]['environment']==units[1]['environment'], 'Runtime environment changed'
    assert len(outputs[0])==len(outputs[1])==20
    for a,b in zip(*outputs):
        assert a['request_id']==b['request_id'] and a['output_token_ids']==b['output_token_ids'], 'Output mismatch'
    metrics = [s['per_request'] for s in summaries]
    rows = []
    for i,(a,b) in enumerate(zip(*metrics),1):
        assert a['request_id']==b['request_id'] and a['output_tokens']==b['output_tokens']
        rows.append({'request_index':i, 'request_id':a['request_id'], 'output_tokens':a['output_tokens'],
                     'initial_tpot_ms':a['tpot_ms'], 'repeat_tpot_ms':b['tpot_ms'],
                     'initial_ttft_ms':a['ttft_ms'], 'repeat_ttft_ms':b['ttft_ms'],
                     'initial_call_ms':a['request_call_ms'], 'repeat_call_ms':b['request_call_ms']})
    report = {'names':NAMES, 'matched_requests':20, 'same_core_command_environment':True,
              'selection':'predeclared complete repeat, no request removal', 'runs':[]}
    for name,s in zip(NAMES,summaries):
        v = [p['tpot_ms'] for p in s['per_request']]
        median = statistics.median(v)
        report['runs'].append({'name':name, 'tpot_median_ms':median, 'tpot_mean_ms':statistics.mean(v),
            'tpot_min_ms':min(v), 'tpot_max_ms':max(v),
            'max_relative_deviation_from_median':max(abs(x/median-1) for x in v),
            'request_indices_over_20pct_above_median':[i for i,x in enumerate(v,1) if x>median*1.2],
            'request_call_median_ms':statistics.median(p['request_call_ms'] for p in s['per_request']),
            'duration_s':s['duration_s'], 'output_throughput_tok_s':s['output_throughput_tok_s']})
    report['repeat_within_15pct_tpot_band'] = report['runs'][1]['max_relative_deviation_from_median']<=.15
    report['repeat_median_within_5pct_initial'] = abs(report['runs'][1]['tpot_median_ms']/report['runs'][0]['tpot_median_ms']-1)<=.05
    report['limitation'] = 'Within-run TPOT dispersion is a diagnostic; it does not prove an exclusive host or absence of interference.'
    (root/'stability_analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    with (root/'stability_requests.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    return report,rows

def plot(root,rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(8.2,3.5))
    for key,label,color in [('initial_tpot_ms','Initial complete run','#A76348'),
                            ('repeat_tpot_ms','Predeclared complete repeat','#2E6C9B')]:
        ax.plot([r['request_index'] for r in rows],[r[key] for r in rows],'.-',label=label,color=color)
    ax.set(xlabel='Request order (all 20 fixed prompts retained)',ylabel='TPOT (ms / token)',
           title='GLM HumanEval · Native-Prefetch · lcw-91, NPU 7')
    ax.set_ylim(bottom=0); ax.set_xticks([1,5,10,15,20]); ax.grid(axis='y',alpha=.2)
    ax.spines[['top','right']].set_visible(False); ax.legend(frameon=False)
    fig.tight_layout()
    for ext in ('png','pdf','svg'):
        fig.savefig(root/f'glm_humaneval_native_stability.{ext}',dpi=200,bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':
    report,rows=audit(ROOT)
    plot(ROOT,rows)
    print(json.dumps(report))
