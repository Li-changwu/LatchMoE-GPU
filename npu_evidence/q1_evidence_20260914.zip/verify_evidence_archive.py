"""Verify all archived bytes; optional extraction is restricted to this artifact directory."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--extract',action='store_true')
    args=parser.parse_args()
    meta=json.loads((ROOT/'evidence_archive.json').read_text(encoding='utf-8'))
    archive=ROOT/meta['archive']
    assert archive.parent.resolve()==ROOT.resolve()
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['sha256']
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        assert len(names)==len(set(names))==meta['files'], 'Unexpected duplicate or missing archive members'
        manifest=json.loads(z.read('evidence_manifest.json'))
        assert set(names)==set(manifest['files'])|{'evidence_manifest.json'}
        for info in z.infolist():
            path=PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in info.filename
            assert not stat.S_ISLNK(info.external_attr>>16)
            destination=(ROOT/Path(*path.parts)).resolve()
            assert destination.is_relative_to(ROOT.resolve()), 'Archive path escapes artifact directory'
            if info.filename in manifest['files']:
                expected=manifest['files'][info.filename]
                data=z.read(info)
                assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'], info.filename
        if args.extract:
            z.extractall(ROOT)
    print(json.dumps({'archive_verified':True,'files':len(names),'extracted':args.extract,
                      'primary_runs':len(manifest['primary_runs']),'matched_requests':manifest['matched_requests']}))
