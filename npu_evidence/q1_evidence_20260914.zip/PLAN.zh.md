# Q1 最新版本重跑（2026-09-14）

用户要求重跑论文Q1，使用最新敲定的LatchMoE优化版本，并寻找三套各20个Prompt的原工作量。本次明确输出上限128，允许EOS；旧Q1原清单上限实际为32，不能把新旧运行混为一轮。

最新方案依据2026-09-12用户确认：统一整理token，固定容量分批，批次图重放；保留原Decode图执行。无量化、无跨层权重借用、无损压缩原型不接入。

数据：ShareGPT、HumanEval、GSM8K原固定20条，保持原prompt、source_id、request_id和顺序。HumanEval按旧清单的字符串排序选择，不能改成数字0–19。派生清单同时将max_output_tokens及context_contract.output_tokens_reserved改为128；两模型各自模板和tokenizer契约保留。三路径每模型每数据集使用相同派生文件。

主矩阵：Qwen3-30B-A3B、GLM-4.7-Flash × 三工作量 × 三方法，18个独立启动，每配置20条顺序请求，TP1、BF16、KV512MiB、模型长度4096、EOS开启、thinking关闭。每单元先完成一次正式启动；不以一次启动构造置信区间。

- LatchMoE：prepare-once＋overflow graph，原Decode replay保留。
- Cache-Offload Eager：相同prepare-once、缓存策略、专家容量和异步加载，全runtime eager且关闭新增overflow graph。这是同策略执行对照，不沿用旧Q1的串行加载Eager数据。
- Native-Prefetch：已合格PIECEWISE图配置，attention分界之外增加wait/start_prefetch分界；作为不同权重搬运组织的系统参考。

Qwen采用12层C32，受管槽3.375GiB；GLM采用12层C5，槽1.0546875GiB且另有共同shared专家权重。Native的Qwen预取权重池相同；GLM Native池多72MiB，须明列，不能宣称内部完全相等。报告整模型allocated/reserved及额外activation/graph池，均须满足同一设备上限。

原wave原型仅硬编码Qwen/C32；本轮最小适配GLM/C5及1536专家中间维度，修正capture预热counts的除不尽余数，逐wave和最终combine以原生路径验证。正式计时不启用参考验证或profiling；启动/编译/capture不混入请求计时。

设备：已完成的 ShareGPT 使用旧服务器，Qwen物理NPU6/NUMA4，GLM物理NPU5/NUMA2。容器迁移至 lcw-91 后，保留六组已完成 ShareGPT 证据，HumanEval 和 GSM8K 在新服务器完整重跑，Qwen固定NPU6/NUMA4，GLM固定NPU7/NUMA2；每个模型/数据集的三方法始终同服务器、同卡、同绑核。旧服务器中断的两组 HumanEval Native 保留且排除，不拼接部分请求。报告明确两台物理服务器，不能把跨机绝对差异解释为数据集差异。

正式并行执行只允许不同NUMA的两条模型队列，记录运行重叠与设备占用，若发现共享资源干扰须串行复测。每条队列内部不同方法不并发。新服务器运行期间保留额外资源快照，用于核对其他作业引起的时间波动。

所有代码、派生工作量及结果写入独立目录，不覆盖旧证据或论文图表。记录命令、显式设备变量、CPU/NUMA绑定、源码及工作量SHA256、逐请求输出、专家账本、图活动、fallback和阶段统计。

完成门槛：18单元每个20请求成功；每个模型/数据集三方法输出token逐条完全一致，缓存策略/权重容量核对，图路径真实发生，任何不适用路径单列。报告TTFT、TPOT、逐请求完整延迟、辅助吞吐和内存；逐请求计算延迟后再汇总，绝不用多个中位数拼造请求时间。
