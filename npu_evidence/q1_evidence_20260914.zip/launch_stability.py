"""Launch exactly one predeclared repeat after both finite model queues finish."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from run_job import ROOT, run, save

NAME = 'glm_humaneval_native_lcw91_stability_r1'

def prerequisites():
    for model in ('qwen','glm'):
        meta=json.loads((ROOT/f'campaign_lcw91_{model}_complete.json').read_text())
        assert meta['status']=='complete' and len(meta['results'])==6
        assert all(u['status']=='complete' and u['exit_code']==0 for u in meta['results'])
    assert not (ROOT/'runs'/NAME).exists(), 'Preserving existing repeat; never launch twice'

if __name__=='__main__':
    prerequisites()
    if '--worker' in sys.argv:
        locks=[]
        for model in ('qwen','glm'):
            lock=(ROOT/f'campaign_lcw91_{model}.lock').open('a')
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            locks.append(lock)
        result=run({'name':NAME,'model':'glm','dataset':'humaneval','arm':'native','requests':20,'verify':False})
        save(ROOT/'stability_campaign.json',result)
        raise SystemExit(result['exit_code'])
    record=ROOT/'stability_launcher.json'
    if record.exists():
        old=json.loads(record.read_text())
        command=Path(f"/proc/{old['pid']}/cmdline")
        if command.exists() and 'launch_stability.py' in command.read_text():
            raise SystemExit('Existing stability launcher is active; not launching another')
        raise SystemExit('Existing launcher record preserved; inspect the previous attempt')
    with (ROOT/'stability_launcher.log').open('x') as log:
        p=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=ROOT,
            env=os.environ.copy(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    data={'pid':p.pid,'name':NAME,'launch_unix':time.time(),'host':'lcw-91'}
    save(record,data)
    print(json.dumps(data))
