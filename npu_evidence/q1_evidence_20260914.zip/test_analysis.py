"""Synthetic report validation in a temporary directory, never performance data."""
import copy
import json
from pathlib import Path
import tempfile
import shutil
from analyze_campaign import analyze, digest, MODELS, DATASETS, ARMS

def save(p,d):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d),encoding='utf-8')
def lines(p,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(json.dumps(r)+'\n' for r in rows),encoding='utf-8')

with tempfile.TemporaryDirectory(prefix='q1-analysis-test-') as tmp:
    root=Path(tmp)
    for name in ('runner.py','wave_worker.py','wave_executor.py','overlay/mock.py'):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('# synthetic fixture\n')
    hashes={p.relative_to(root).as_posix():digest(p) for p in root.rglob('*.py')}
    for model in MODELS:
        for dataset in DATASETS:
            ids=[f'{dataset}_{i}' for i in range(20)]
            manifest=root/'manifests'/f'{model}_{dataset}_20_max128.jsonl'
            lines(manifest,[{'request_id':i} for i in ids])
            for arm in ARMS:
                d=root/'runs'/f'{model}_{dataset}_{arm}_r1'
                u={'status':'complete','exit_code':0,'verify':False,'manifest_sha256':digest(manifest),
                   'device':6 if model=='qwen' else 5,'numa_node':4 if model=='qwen' else 2,
                   'source_hashes':hashes,'start_unix':0,'finish_unix':20}
                per=[{'request_id':i,'output_tokens':3,'ttft_ms':100,'tpot_ms':20,
                      'request_stream_ms':140,'request_call_ms':145} for i in ids]
                s={'status':'ok','completed':20,'requested_request_ids':ids,'ignore_eos':False,
                   'disable_thinking':True,'tensor_parallel_size':1,'request_batch_size':1,
                   'npu_profiler_dir':None,'async_load':True,
                   'execution_mode':'eager' if arm=='eager' else 'graph','native_offload_enabled':arm=='native',
                   'qualification_diagnostics':{'compilation_config_override':{'splitting_ops':[
                       'vllm::wait_prefetch','vllm::start_prefetch']}},'per_request':per,
                   'total_output_tokens':60,'duration_s':2.9,'output_throughput_tok_s':60/2.9}
                a={'calls':24,'fallbacks':0,'verified':0,'graphs':108 if arm=='latchmoe' else 0,
                   'replays':86 if arm=='latchmoe' else 0}
                w={'vllm_file':'/workspace/latchmoe-locked-stack/vllm-hust/vllm/__init__.py',
                   'vllm_ascend_file':'/workspace/latchmoe-locked-stack/vllm-ascend-hust/vllm_ascend/__init__.py',
                   'package_file':(root/'overlay/mock.py').as_posix(),
                   'wave_reuse':{'decode_addresses_unchanged':True,'arena':a if arm!='native' else None},
                   'audit':{'expert_replay_pieces':10 if arm=='latchmoe' else 0,
                            'misses':10,'h2d_bytes':1024,'digest':'synthetic','waves':10},
                   'managed_memory_ledger':{'registered_layers':12,'original_expert_weights_retained':False,
                       'slot_bank_bytes':3623878656 if model=='qwen' else 1132462080},
                   'allocated_bytes':2**30,'reserved_bytes':2**30,'peak_allocated_bytes':2**30,'peak_reserved_bytes':2**30}
                save(d/'unit.json',u);save(d/'summary.json',s);save(d/'worker_after.json',[w])
                (d/'runner.log').write_text('synthetic: Replaying aclgraph\n')
                lines(d/'outputs.jsonl',[{'request_id':i,'output_token_ids':[11,12,13]} for i in ids])
    r=analyze(root)
    assert r['valid'] and len(r['units'])==18 and sum(c['exact_match_requests'] for c in r['comparisons'])==240,r['errors']
    target=root/'runs/qwen_sharegpt_eager_r1'
    out=[{'request_id':f'sharegpt_{i}','output_token_ids':[11,12,13]} for i in range(20)]
    out[3]['output_token_ids']=[11,99,13];lines(target/'outputs.jsonl',out)
    r=analyze(root)
    bad=[c for c in r['comparisons'] if c['mismatches']]
    assert not r['valid'] and len(bad)==1 and bad[0]['mismatches'][0]['first_mismatch_position']==1
    out[3]['output_token_ids']=[11,12,13];lines(target/'outputs.jsonl',out)
    original=json.loads((target/'summary.json').read_text())
    broken=copy.deepcopy(original);broken['per_request'][0]['ttft_ms']=float('nan');save(target/'summary.json',broken)
    r=analyze(root);assert not r['valid'] and any('ttft' in e['error'] for e in r['errors'])
    save(target/'summary.json',original)
    original_unit=json.loads((target/'unit.json').read_text())
    broken=copy.deepcopy(original_unit);broken['device']=4;save(target/'unit.json',broken)
    r=analyze(root);assert not r['valid'] and any('device' in e['error'] for e in r['errors'])
    save(target/'unit.json',original_unit)
    broken=copy.deepcopy(original_unit);broken['status']='running';save(target/'unit.json',broken)
    r=analyze(root);assert not r['complete'] and len(r['missing'])==1
    save(target/'unit.json',original_unit)
    retry=target.with_name('qwen_sharegpt_eager_lcw91_r1')
    shutil.copytree(target,retry)
    migrated=copy.deepcopy(original_unit);migrated['execution_host']='lcw-91'
    save(retry/'unit.json',migrated)
    save(root/'selected_runs.json',{'qwen_sharegpt_eager_r1':retry.name})
    r=analyze(root)
    assert not r['valid'] and any('different environments' in e['error'] for e in r['errors'])
    for arm in ('latchmoe','native'):
        path=root/'runs'/f'qwen_sharegpt_{arm}_r1'/'unit.json'
        unit=json.loads(path.read_text());unit['execution_host']='lcw-91';save(path,unit)
    save(target/'unit.json',broken)
    r=analyze(root)
    assert r['valid'] and any(x['name']==retry.name for x in r['units']),r['errors']
    canonical='glm_humaneval_native_r1';repeat='glm_humaneval_native_stability_test_r1'
    save(root/'stability_plan.json',{'canonical':canonical,'required_primary':repeat})
    r=analyze(root)
    assert r['complete'] and not r['valid'] and len(r['pending_quality_checks'])==2
    shutil.copytree(root/'runs'/canonical,root/'runs'/repeat)
    selected=json.loads((root/'selected_runs.json').read_text());selected[canonical]=repeat
    save(root/'selected_runs.json',selected)
    r=analyze(root)
    assert r['complete'] and not r['valid'] and len(r['pending_quality_checks'])==1
    audit={'names':[canonical,repeat],'matched_requests':20,'same_core_command_environment':True,
           'repeat_within_15pct_tpot_band':False,'repeat_median_within_5pct_initial':True}
    save(root/'stability_analysis.json',audit)
    r=analyze(root)
    assert not r['valid'] and any('stability repeat' in e['error'] for e in r['errors'])
    audit['repeat_within_15pct_tpot_band']=True;save(root/'stability_analysis.json',audit)
    r=analyze(root)
    assert r['valid'] and not r['pending_quality_checks'],r['errors']
    audit['repeat_median_within_5pct_initial']=False;save(root/'stability_analysis.json',audit)
    r=analyze(root)
    assert not r['valid'] and any('stability repeat' in e['error'] for e in r['errors'])
print(json.dumps({'status':'passed','cases':12,'synthetic_only':True}))
