"""Opt-in local BF16 packed waves using reusable indexed activation storage.

The expert cache policy is unchanged. All buffers have explicit bounds; graph
captures include gather, grouped MLP, and scattering to logical expert order.
The shared activation arena is sequential-only and never aliases expert weights.
"""
import os
import time
from dataclasses import replace

BUCKETS = (128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768)
MAX_PAIRS = 32768

def build_index_plan(token_counts, group, physical, capacity, bucket, sentinel):
    import numpy as np
    offsets, cursor = {}, 0
    for expert, count in sorted(token_counts.items()):
        count = int(count)
        if count <= 0:
            raise ValueError('Active counts must be positive')
        offsets[int(expert)] = (cursor, cursor+count)
        cursor += count
    if cursor > sentinel:
        raise ValueError('Activation arena capacity exceeded')
    ordered = sorted(group, key=lambda e: physical[int(e)])
    slots = [int(physical[int(e)]) for e in ordered]
    if (len(set(group)) != len(group) or len(set(slots)) != len(slots)
            or any(s < 0 or s >= capacity for s in slots)):
        raise ValueError('Invalid physical expert assignment')
    actual = sum(int(token_counts[e]) for e in ordered)
    if actual <= 0 or actual > bucket:
        raise ValueError('Invalid wave row capacity')
    indices = np.full(bucket, sentinel, dtype=np.int64)
    counts = np.zeros(capacity, dtype=np.int64)
    cursor = 0
    for expert in ordered:
        start, end = offsets[expert]
        indices[cursor:cursor+end-start] = np.arange(start,end,dtype=np.int64)
        counts[physical[expert]] = end-start
        cursor += end-start
    # Dummy rows occur after every real row and belong to the final slot.
    counts[-1] += bucket-actual
    return indices, counts, actual

class Arena:
    def __init__(self, runtime, arm):
        start = time.perf_counter()
        import torch
        from vllm_ascend.ops.fused_moe.moe_mlp import unquant_apply_mlp
        self.torch, self.mlp, self.arm = torch, unquant_apply_mlp, arm
        self.capacity = int(runtime.config.num_slots)
        if self.capacity not in (5,32):
            raise RuntimeError('Q1 qualification supports Qwen C32 and GLM C5')
        bank = next(iter(runtime._slot_banks.values()))
        self.device = bank.w13_slots.device
        self.hidden = 2048
        self.x = torch.zeros(MAX_PAIRS+1,self.hidden,dtype=torch.bfloat16,device=self.device)
        self.y = torch.empty_like(self.x)
        self.metadata = torch.zeros(MAX_PAIRS+self.capacity,dtype=torch.int64,device=self.device)
        self.graphs, self.weights = {}, {}
        self.calls, self.waves, self.replays, self.verified = 0,0,0,0
        self.max_error, self.fallbacks, self.padded_rows, self.real_rows = 0.0,0,0,0
        self.verified_layers = 0
        self.layer_tokens, self.phase_counts = [], {}
        self.pointer_records = {}
        self.busy = False
        pool = torch.npu.graph_pool_handle() if arm == 'graph' else None
        for layer, bank in sorted(runtime._slot_banks.items()):
            w1,w2 = bank.w13_slots,bank.w2_slots
            intermediate = 768 if self.capacity == 32 else 1536
            if tuple(w1.shape)==(self.capacity,2048,2*intermediate) and tuple(w2.shape)==(self.capacity,intermediate,2048):
                trans = False
            elif tuple(w1.shape)==(self.capacity,2*intermediate,2048) and tuple(w2.shape)==(self.capacity,2048,intermediate):
                trans = True
            else:
                raise RuntimeError('Unsupported bank shapes: '+str((w1.shape,w2.shape)))
            self.weights[layer] = (w1,w2,trans)
            self.pointer_records[layer] = (w1.data_ptr(),w2.data_ptr(),runtime._log2phy_buffers[layer].data_ptr())
            if arm != 'graph':
                continue
            # Shared graph scratch is consumed entirely within each replay.
            # No temporary captured output escapes; calls use one stream in order.
            for bucket in reversed(BUCKETS):
                self.metadata[:bucket].zero_()
                self.metadata[bucket:bucket+self.capacity].fill_(bucket//self.capacity)
                self.metadata[bucket+self.capacity-1] += bucket % self.capacity
                for _ in range(2):
                    self.body(layer,bucket)
                torch.npu.synchronize()
                graph = torch.npu.NPUGraph()
                with torch.npu.graph(graph,pool=pool):
                    self.body(layer,bucket)
                torch.npu.synchronize()
                self.graphs[layer,bucket] = graph
        self.setup_ms = (time.perf_counter()-start)*1000
        self.process_peak_before_measurement_bytes = torch.npu.max_memory_allocated()
        self.explicit_buffer_bytes = sum(t.numel()*t.element_size() for t in (self.x,self.y,self.metadata))

    def body(self, layer, bucket):
        w1,w2,trans = self.weights[layer]
        indices = self.metadata[:bucket]
        counts = self.metadata[bucket:bucket+self.capacity]
        wave_x = self.x.index_select(0,indices)
        wave_y, _ = self.mlp(wave_x,w1,w2,counts,need_trans=trans,group_list_type=1)
        # Padding writes only to an unused sentinel row. All real indices are
        # unique and the entire layer's real row set is covered by its waves.
        self.y.index_copy_(0,indices,wave_y)

    def evidence(self):
        return {k:getattr(self,k) for k in ('arm','calls','waves','replays','verified','max_error',
            'fallbacks','padded_rows','real_rows','layer_tokens','phase_counts','setup_ms',
            'process_peak_before_measurement_bytes','explicit_buffer_bytes','verified_layers')} | {'graphs':len(self.graphs)}

def run_indexed(comm, arena, original, **kwargs):
    import torch
    from vllm_ascend.ops.fused_moe.moe_comm_method import build_token_dispatch_input, FusedExpertsResult
    from vllm_ascend.ops.fused_moe.token_dispatcher import TokenDispatcherWithAllGather
    from vllm_ascend.ops.fused_moe.moe_runtime_args import MoEMlpComputeInput
    from vllm_moe_offload_ascend.moe_offload.phase_split import plan_main_cache_waves
    from vllm_moe_offload_ascend.moe_offload.runtime import get_moe_offload_runtime
    from vllm_moe_offload_ascend.patches.patch_fused_moe import _unpack_mlp_apply_result
    inp, counts, readiness = (kwargs[k] for k in ('fused_experts_input','token_counts','readiness'))
    layer = int(inp.offload.layer_id)
    if (int(inp.topk_ids.numel()) > MAX_PAIRS or layer not in arena.weights
        or inp.hidden_states.dtype != torch.bfloat16 or inp.hidden_states.shape[-1] != arena.hidden
        or not isinstance(comm.token_dispatcher,TokenDispatcherWithAllGather)
        or inp.routing.expert_map is not None or inp.routing.pertoken_scale is not None
        or inp.routing.apply_router_weight_on_input or inp.quant.is_quant
        or inp.quant.dispatch_with_quant or inp.weights.w1_bias is not None or inp.weights.w2_bias is not None
        or inp.dynamic_eplb or getattr(inp.activation,'value',inp.activation)=='swigluoai'):
        arena.fallbacks += 1
        return original(comm,**kwargs)
    if arena.busy:
        raise RuntimeError('Activation arena requires sequential layer execution')
    arena.busy = True
    try:
        runtime = get_moe_offload_runtime()
        active = tuple(sorted(int(e) for e,n in counts.items() if int(n)>0))
        hits = tuple(e for e in active if readiness.get(e,False))
        specs = plan_main_cache_waves(active,arena.capacity,hit_experts=hits,policy='packed')
        verify = os.environ.get('WAVE_VERIFY')=='1'
        global_input = replace(inp,routing=replace(inp.routing,log2phy=None,
            physical_expert_count=int(inp.offload.num_logical_experts)))
        dispatch = comm.token_dispatcher.token_dispatch(
            token_dispatch_input=build_token_dispatch_input(fused_experts_input=global_input))
        total = int(inp.topk_ids.numel())
        if dispatch.hidden_states.shape[0] != total or sum(counts.values()) != total:
            raise RuntimeError('Routed-pair coverage mismatch')
        if verify:
            from vllm_moe_offload_ascend.moe_offload.phase_split import (
                build_b2_routed_pair_index, build_b2_wave_microbatch_plan,
                build_b2_pair_microbatch_from_plan, B2DirectScatterPayload,
                build_b2_native_combine_inputs)
            expected_histogram = [int(counts.get(e,0)) for e in range(inp.offload.num_logical_experts)]
            if dispatch.group_list.cpu().tolist()!=expected_histogram:
                raise AssertionError('Native global histogram differs from routed expert counts')
            pair_index = build_b2_routed_pair_index(inp.topk_ids,inp.topk_weights)
            reference_payloads = []
        if bool(inp.need_trans) != arena.weights[layer][2]:
            raise RuntimeError('Weight layout differs from the qualified graph')
        arena.x[:total].copy_(dispatch.hidden_states)
        arena.x[MAX_PAIRS].zero_()
        visited = []
        for spec in specs:
            group = tuple(spec.active_experts)
            prepared,event,payload = runtime.prepare_main_cache_wave_plan(
                layer_id=layer,active_experts=group,num_logical_experts=inp.offload.num_logical_experts,
                device=inp.topk_ids.device,protected_experts=(),async_load=bool(runtime.config.async_load))
            runtime.wait_prefill_stage_plan(event)
            runtime.publish_main_cache_mapping(prepared)
            prepared.validate_backend_ready(expected_device_type=inp.offload.expected_device_type)
            physical = {int(e):s for s,e in enumerate(prepared.mapping.slot_to_expert) if e is not None}
            actual = sum(int(counts[e]) for e in group)
            bucket = next(b for b in BUCKETS if b>=actual)
            indices, histogram, actual = build_index_plan(counts,group,physical,arena.capacity,bucket,MAX_PAIRS)
            # Fresh pinned source: its allocator tracks the async copy lifetime.
            host = torch.empty(bucket+arena.capacity,dtype=torch.int64,pin_memory=True)
            host.numpy()[:bucket] = indices
            host.numpy()[bucket:] = histogram
            arena.metadata[:bucket+arena.capacity].copy_(host,non_blocking=True)
            handle = runtime.begin_slot_compute(prepared)
            try:
                if arena.arm=='graph':
                    arena.graphs[layer,bucket].replay()
                    arena.replays += 1
                else:
                    arena.body(layer,bucket)
                if verify:
                    real_indices = torch.tensor(indices[:actual],dtype=torch.int64,device=arena.device)
                    reference_counts = histogram.copy()
                    reference_counts[-1] -= bucket-actual
                    pair_plan = build_b2_wave_microbatch_plan(pair_index,group,
                        physical_slot_by_expert=physical,preserve_pair_order=False,
                        include_logical_expert_ids=False,include_topk_positions=False)
                    micro = build_b2_pair_microbatch_from_plan(inp.hidden_states,inp.topk_weights,None,pair_plan)
                    reference_input = replace(global_input,hidden_states=micro.hidden_states,
                        topk_ids=micro.topk_ids,topk_weights=micro.topk_weights,
                        routing=replace(global_input.routing,physical_expert_count=prepared.physical_expert_count))
                    old_top_k = comm.token_dispatcher.top_k
                    comm.token_dispatcher.top_k = 1
                    try:
                        reference_dispatch = comm.token_dispatcher.token_dispatch(
                            token_dispatch_input=build_token_dispatch_input(fused_experts_input=reference_input))
                    finally:
                        comm.token_dispatcher.top_k = old_top_k
                    indexed_x = dispatch.hidden_states.index_select(0,real_indices)
                    if (reference_dispatch.group_list.cpu().tolist()!=reference_counts.tolist()
                        or not torch.equal(reference_dispatch.hidden_states,indexed_x)):
                        raise AssertionError('Indexed wave inputs differ from original per-wave native dispatch')
                    mlp_input = MoEMlpComputeInput(
                        hidden_states=reference_dispatch.hidden_states,
                        group_list=torch.tensor(reference_counts,dtype=torch.int64,device=arena.device),
                        group_list_type=1,dynamic_scale=None,topk_scales=None,
                        weights=replace(inp.weights,w1=prepared.w1,w2=prepared.w2),
                        quant=inp.quant,fusion=comm.use_fusion_ops,activation=inp.activation,
                        need_trans=inp.need_trans,dynamic_eplb=inp.dynamic_eplb,swiglu_limit=inp.swiglu_limit)
                    expected,_ = _unpack_mlp_apply_result(comm._apply_mlp(mlp_input))
                    actual_y = arena.y.index_select(0,real_indices)
                    error = float((expected.float()-actual_y.float()).abs().max().item())
                    arena.max_error = max(arena.max_error,error)
                    if not torch.equal(expected,actual_y):
                        raise AssertionError('Indexed wave output mismatch: '+str((layer,actual,bucket,error)))
                    reference_payloads.append(B2DirectScatterPayload(
                        permuted_tokens=expected,
                        expanded_row_idx=reference_dispatch.combine_metadata.expanded_row_idx,
                        topk_weights=micro.topk_weights,
                        restore_token_indices=micro.restore_token_indices,
                        wave_index=len(reference_payloads),pair_offsets=pair_plan.pair_offsets,
                        combine_metadata=reference_dispatch.combine_metadata))
                    visited.extend(indices[:actual].tolist())
                    arena.verified += 1
            finally:
                runtime.end_slot_compute(handle)
            runtime.mark_main_cache_wave_compute_complete(layer_id=layer,
                wave_id=int(payload.get('wave_plan',{}).get('wave_id',-1)),prepared=prepared)
            arena.waves += 1
            arena.real_rows += actual
            arena.padded_rows += bucket-actual
        if verify and sorted(visited)!=list(range(total)):
            raise AssertionError('Real pairs are missing or duplicated')
        combined = comm.token_dispatcher.token_combine(
            hidden_states=arena.y[:total],combine_metadata=dispatch.combine_metadata)
        if verify:
            reference_y, reference_indices, reference_metadata = build_b2_native_combine_inputs(
                tuple(reference_payloads),total_pairs=total)
            reference_combined = comm.token_dispatcher.token_combine(
                hidden_states=reference_y,combine_metadata=replace(reference_metadata,
                    topk_weights=inp.topk_weights,expanded_row_idx=reference_indices,
                    restore_shape=inp.hidden_states.shape))
            if not torch.equal(combined,reference_combined):
                raise AssertionError('Final layer output differs from original native combine')
            arena.verified_layers += 1
        # Publish to fresh storage before the next layer can overwrite the arena.
        accumulated = torch.zeros_like(inp.hidden_states,dtype=torch.float32)
        accumulated.add_(combined.to(accumulated.dtype))
        arena.calls += 1
        arena.layer_tokens.append((layer,int(inp.hidden_states.shape[0])))
        phase = str(kwargs.get('forward_phase','unknown'))
        arena.phase_counts[phase] = arena.phase_counts.get(phase,0)+1
        done = torch.npu.current_stream().record_event()
        return FusedExpertsResult(routed_out=accumulated.to(inp.hidden_states.dtype),
            before_dispatch_evt=kwargs['before_dispatch_evt'],before_gmm2_evt=None,
            before_combine_evt=done,group_list_type=1,expert_tokens=None,swiglu_limit=inp.swiglu_limit)
    finally:
        arena.busy = False
