# Q1 补测交付目录

本目录独立保存 2026-09-14 的 Q1 重跑，不覆盖论文现有数字和图表。缺失的 HumanEval/GSM8K 十二组及预定稳定性复测已完成；主矩阵 18 组 / 360 条请求、12 项 / 240 条成对输出比较全部通过，`analysis.json` 的 complete 与 valid 均为 true。

优先查看 `RESULTS.zh.md` 和 `eval_q1_serving_rerun.pdf`；原始数字在 `results.csv`，完整请求延迟见 `eval_q1_request_latency.pdf`。三张图均有 PDF/SVG/PNG 版本。`q1_evidence_20260914.zip` 保存独立原始记录与复现脚本，`evidence_manifest.json` 提供逐文件摘要，外层归档摘要见 `evidence_archive.json`。

## 口径

- Qwen3-30B-A3B、GLM-4.7-Flash；BF16，不使用量化，专家权重不变。
- ShareGPT、HumanEval、GSM8K 各保留历史清单中的固定 20 条 Prompt、原顺序和模型专用模板。旧清单实际最多生成 32 token，本轮上限统一改为 128，允许 EOS 提前停止。
- 三方法分别为最新 LatchMoE（统一整理 token、固定容量 overflow 批次图重放及已有 Decode 图）、同策略 Cache-Offload Eager、Native-Prefetch。Eager 也使用异步加载，不能沿用旧论文对串行 Eager 的描述。
- 主矩阵每配置选用一组完整启动、20 条顺序请求；GLM HumanEval Native 另有一次预定完整复测，首次运行也完整保留。TP1、KV 512 MiB、最大模型长度 4096。启动、编译、批次图捕获与正式请求计时分开；无跨启动置信区间。
- 主指标是逐请求实测完整耗时、TTFT、TPOT；吞吐和内存一并保存。逐条计算再汇总，不能用多个中位数拼出完整延迟。

## 迁移与稳定性

ShareGPT 的六组完整结果来自原服务器。其余十二组在容器迁移后的 `lcw-91` 完整运行。旧两组 HumanEval Native 因迁移中断，保留且排除，不拼接部分结果。每个模型/数据集的三方法固定同服务器、同卡、同 NUMA；跨服务器的绝对差异不能解释为数据集效应。详见 `PLAN.zh.md`、`migration_lcw91_audit.json`。

新服务器 Qwen 使用 NPU6/NUMA4，GLM 使用 NPU7/NUMA2。同卡不存在本实验两个方法并发；整机还有其他作业。GLM HumanEval Native 发现阶段性波动后，已预先安排额外完整复测，见 `STABILITY.zh.md`。保留全部运行记录，不能通过剔除慢请求或按最快结果选择改善收益。

## 证据与复现

- `manifests/`：六份模型/数据集专用清单；`manifest_audit.json` 保存源清单追溯。
- `runner.py`、`wave_executor.py`、`wave_worker.py`、`overlay/`：冻结的运行核心。`run_job.py` 记录实际命令、环境、CPU/NUMA、源码和清单摘要。
- `runs/<运行名>/`：`unit.json` 启动信息、`summary.json` 汇总和逐请求指标、`outputs.jsonl` 实际输出 token、`request_call_times.jsonl` 实测完整调用耗时、`worker_before/after.json` 路径/缓存/图/内存证据、日志及前后设备快照。
- `selected_runs.json`：主矩阵选用的完整运行。所有未选运行仍保留。
- `resource_samples/`：新服务器运行中的外部资源快照；`stack_snapshot_*.json` 和迁移审计记录运行库来源。
- `analyze_campaign.py`：检查 18 组、固定输入、输出长度和逐 token 一致性、路径/源码、图执行、缓存容量等，生成 `analysis.json`、`results.csv`、`RESULTS.zh.md`。CPU 上的验证器测试不等同于 NPU 性能结果。
- `plot_results.py`：只有完整矩阵通过验证后才能生成独立 PDF/SVG/PNG 图表。

完整验收包括 18 组共 360 条正式请求，以及 12 项成对比较中的 240 条逐 token 一致检查。LatchMoE/Eager 的相同缓存策略不表示缓存历史相同，搬运量和 misses 单列；GLM Native 预取池比 LatchMoE 动态专家槽多 72 MiB，也须披露。

运行库固定于 vLLM `ad7125a431e176d4161099480a66f0169609a690` 和 vLLM-Ascend `4806367eeeb7d62b32078ae90cd929cc06d825fe`，原工作树与本目录的冻结 overlay 分别记录。新服务器资格检查已通过：Qwen 86 个批次、GLM 279 个批次逐位一致，最大误差与回退次数均为 0；正式计时关闭参考验证。
