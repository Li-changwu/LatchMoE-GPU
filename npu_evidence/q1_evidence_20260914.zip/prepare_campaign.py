"""Freeze previously qualified runtime and request identities for Q1 rerun."""
import collections
import gzip
import hashlib
import json
import pathlib
import shutil

ROOT=pathlib.Path('/workspace/latchmoe-q1-rerun-20260914')
OLD=pathlib.Path('/workspace/latchmoe-eurosys-rebuild-20260911')
WAVE=pathlib.Path('/workspace/latchmoe-wave-reuse-20260912')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
ROOT.mkdir(exist_ok=True)
(ROOT/'manifests').mkdir(exist_ok=True)
if not (ROOT/'overlay').exists():
    shutil.copytree(WAVE/'overlay',ROOT/'overlay',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
units={}
manifest_audit={}
for model in ('qwen','glm'):
    dirname='qwen3-30b-a3b' if model=='qwen' else 'glm-4.7-flash'
    path=pathlib.Path('/workspace/latchmoe-evaluation20-q1-derived-20260906')/dirname/'manifest.jsonl.gz'
    raw=gzip.decompress(path.read_bytes()).decode()
    records=[json.loads(line) for line in raw.split('\n') if line.strip()]
    shutil.copyfile(path,ROOT/'manifests'/f'{model}_source_original.jsonl.gz')
    manifest_audit[model]={'source':str(path),'source_sha256':sha(path),'source_rows':len(records),'datasets':{}}
    for dataset in ('sharegpt','humaneval','gsm8k'):
        selected=[r for r in records if r['dataset'].lower()==dataset]
        assert len(selected)==20,(model,dataset,len(selected))
        out=ROOT/'manifests'/f'{model}_{dataset}_20_max128.jsonl'
        derived=[dict(r,max_output_tokens=128,context_contract=dict(r.get('context_contract',{}),output_tokens_reserved=128)) for r in selected]
        out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in derived))
        manifest_audit[model]['datasets'][dataset]={
            'selected_count':20,'original_output_caps':sorted(set(r['max_output_tokens'] for r in selected)),
            'new_output_cap':128,'derived_path':str(out),'derived_sha256':sha(out),
            'bucket':selected[0]['bucket'],'request_ids':[r['request_id'] for r in selected],
            'source_ids':[r.get('source_id') for r in selected],
            'prompt_hashes':[hashlib.sha256(r['prompt'].encode()).hexdigest() for r in selected],
            'raw_prompt_tokens':[r.get('prompt_tokens') for r in selected],
            'source_context_contract':selected[0].get('context_contract'),
            'change':'max_output_tokens and context_contract.output_tokens_reserved changed to128; original prompt/order/seed retained.'}
        stem=('sg' if model=='qwen' and dataset=='sharegpt' else dataset)
        for arm,oldarm in [('latchmoe','replay'),('native','native_seam')]:
            p=OLD/'runs'/f'{model}_{stem}_{oldarm}_r1'/'unit.json'
            d=json.loads(p.read_text())
            units[f'{model}_{dataset}_{arm}']={'path':str(p),'sha256':sha(p),'command':d['command'],'source_hashes':d['source_hashes']}
save(ROOT/'base_units.json',units)
save(ROOT/'manifest_audit.json',manifest_audit)
save(ROOT/'original_overlay_hashes.json',{str(p.relative_to(WAVE/'overlay')):sha(p) for p in (WAVE/'overlay').rglob('*.py')})
save(ROOT/'model_configs.json',{m:json.loads((pathlib.Path(units[f'{m}_sharegpt_latchmoe']['command'][units[f'{m}_sharegpt_latchmoe']['command'].index('--model')+1])/'config.json').read_text()) for m in ('qwen','glm')})
print(json.dumps({m:{d:{k:v for k,v in a.items() if k in ('selected_count','original_output_caps','bucket','raw_prompt_tokens','source_context_contract')} for d,a in x['datasets'].items()} for m,x in manifest_audit.items()},indent=2))
