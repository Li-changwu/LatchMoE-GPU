"""Compact snapshot of the foreground experiment campaign."""
import json
from pathlib import Path
import time
root=Path(__file__).resolve().parent
completed=[];active=[];failed=[]
excluded=[];other_completed=[]
selected=json.loads((root/'selected_runs.json').read_text()) if (root/'selected_runs.json').exists() else {}
for p in sorted((root/'runs').glob('*_r1/unit.json')):
    u=json.loads(p.read_text())
    if p.parent.name in selected and selected[p.parent.name]!=p.parent.name:
        excluded.append(p.parent.name)
        continue
    canonical=f"{u['model']}_{u['dataset']}_{u['arm']}_r1"
    primary=selected.get(canonical,canonical)
    if u['status']=='complete':
        (completed if p.parent.name==primary else other_completed).append(u['name'])
    elif u['status']=='failed': failed.append(u['name'])
    else:
        calls=p.parent/'request_call_times.jsonl'
        rows=[json.loads(x) for x in calls.read_text().split('\n') if x] if calls.exists() else []
        log=p.parent/'runner.log'
        tail=log.read_text(errors='replace').strip().split('\n')[-1][-220:] if log.exists() else ''
        active.append({'name':u['name'],'requests':len(rows),'elapsed_s':round(time.time()-u['start_unix']),
                       'last_call_ms':rows[-1].get('request_call_ms') if rows else None,'last_log':tail})
print(json.dumps({'completed':completed,'active':active,'failed':failed,'excluded_migration_partials':excluded,
                  'other_completed':other_completed},ensure_ascii=False))
