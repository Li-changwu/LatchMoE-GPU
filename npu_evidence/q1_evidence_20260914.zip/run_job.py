"""Isolated Q1 start. No previous run or request selection is overwritten."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT=Path('/workspace/latchmoe-q1-rerun-20260914')
REPO=Path('/workspace/vllm-ascend-hust-LatchMoE')
def save(p,d):
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
    tmp.replace(p)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def device_snapshot(out,label):
    result=subprocess.run(['npu-smi','info'],capture_output=True,text=True,timeout=30)
    (out/f'device_{label}.txt').write_text(result.stdout+result.stderr)
def run(job):
    name,model,dataset,arm=(job[k] for k in ('name','model','dataset','arm'))
    out=ROOT/'runs'/name
    out.mkdir(parents=True,exist_ok=False)
    base_units=json.loads((ROOT/'base_units.json').read_text())
    base=base_units[f'{model}_{dataset}_{"native" if arm=="native" else "latchmoe"}']
    cmd=base['command'][:]
    cmd[2]=str(ROOT/'runner.py')
    def setarg(flag,value):
        if flag in cmd: cmd[cmd.index(flag)+1]=str(value)
        else: cmd.extend([flag,str(value)])
    def remove(flag,has_value=False):
        if flag in cmd:
            i=cmd.index(flag)
            del cmd[i:i+2 if has_value else i+1]
    manifest=ROOT/'manifests'/f'{model}_{dataset}_20_max128.jsonl'
    setarg('--output-dir',out)
    setarg('--manifest',manifest)
    setarg('--buckets',f'q1_{dataset}_20')
    setarg('--max-requests',job.get('requests',20))
    setarg('--override-max-output-tokens',128)
    for flag in ('--enforce-eager','--diagnostic-eager','--no-async-load'):
        remove(flag)
    if arm=='eager': cmd += ['--enforce-eager','--diagnostic-eager']
    if arm!='native' and '--async-load' not in cmd: cmd += ['--async-load']
    device=int(job.get('device',6 if model=='qwen' else 7))
    numa={4:4,5:2,6:4,7:2}[device]
    env=os.environ.copy()
    # Remove inherited experiment overrides; retain normal runtime paths.
    for k in list(env):
        if k.startswith(('WAVE_','LATCHMOE_','VLLM_ASCEND_MOE_OFFLOAD_','VLLM_ASCEND_MOE_GMM_')):
            env.pop(k)
    env.update({'ASCEND_RT_VISIBLE_DEVICES':str(device),'ASCEND_VISIBLE_DEVICES':str(device),
        'PYTHONPATH':f'{ROOT}:{ROOT}/overlay:{REPO}:'+':'.join(p for p in env.get('PYTHONPATH','').split(':') if p.startswith('/usr/local/Ascend/')),
        'VLLM_WORKER_MULTIPROC_METHOD':'spawn',
        'LATCHMOE_BASE_REPO':str(REPO),
        'LATCHMOE_WAVE_POLICY':'packed','LATCHMOE_BOUNDARY_LEASES':'1',
        'LATCHMOE_REVISION_EXPERT_EAGER':'0',
        'VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH':'','VLLM_ASCEND_MOE_OFFLOAD_PROFILE_PATH':'',
        'VLLM_ASCEND_MOE_GMM_TRACE_PATH':'','VLLM_ASCEND_MOE_GMM_PROFILE_PATH':'',
        'WAVE_ARM':{'latchmoe':'graph','eager':'indexed','native':'baseline'}[arm],
        'WAVE_VERIFY':'1' if job.get('verify') else '0'})
    if arm!='native':
        env.update(VLLM_ASCEND_MOE_OFFLOAD_GB='13.5',VLLM_ASCEND_MOE_OFFLOAD_DIAGNOSTIC_MODE='1')
    launch=['numactl',f'--cpunodebind={numa}',f'--membind={numa}']+cmd
    meta={**job,'execution_host':'lcw-91','command':cmd,'launch_command':launch,'manifest':str(manifest),'manifest_sha256':digest(manifest),
          'device':device,'numa_node':numa,'base_unit':base['path'],'status':'running','start_unix':time.time(),
          'source_hashes':{str(p.relative_to(ROOT)):digest(p) for p in list(ROOT.glob('*.py'))+list((ROOT/'overlay').rglob('*.py'))},
          'environment':{k:v for k,v in env.items() if k.startswith(('WAVE_','LATCHMOE_','VLLM_ASCEND_MOE_','ASCEND_')) or k in ('PYTHONPATH','VLLM_WORKER_MULTIPROC_METHOD')},
          'numactl_policy':subprocess.check_output(['numactl',f'--cpunodebind={numa}',f'--membind={numa}','numactl','--show'],text=True)}
    save(out/'unit.json',meta)
    device_snapshot(out,'before')
    with (out/'runner.log').open('w') as log:
        proc=subprocess.Popen(launch,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        meta['pid']=proc.pid
        save(out/'unit.json',meta)
        try: rc=proc.wait(timeout=job.get('timeout',3600))
        except subprocess.TimeoutExpired:
            meta['timeout']=True
            os.killpg(proc.pid,signal.SIGTERM)
            try: rc=proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                rc=proc.wait()
    meta.update(exit_code=rc,finish_unix=time.time(),status='complete' if rc==0 else 'failed')
    save(out/'unit.json',meta)
    device_snapshot(out,'after')
    print(json.dumps({k:meta[k] for k in ('name','status','exit_code')}),flush=True)
    return meta

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('name')
    p.add_argument('--model',choices=['qwen','glm'],required=True)
    p.add_argument('--dataset',choices=['sharegpt','humaneval','gsm8k'],default='sharegpt')
    p.add_argument('--arm',choices=['latchmoe','eager','native'],default='latchmoe')
    p.add_argument('--requests',type=int,default=20)
    p.add_argument('--verify',action='store_true')
    a=vars(p.parse_args())
    raise SystemExit(run(a)['exit_code'])
