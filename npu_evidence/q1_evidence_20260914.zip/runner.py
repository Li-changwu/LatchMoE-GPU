# SPDX-License-Identifier: Apache-2.0
"""Run a minimal fixed-slot SEW-Offload smoke workload.

This runner is intentionally small and artifact-oriented. It is for checking
whether the MVP-D fixed-slot path reaches generation on a real NPU; it is not a
publishable benchmark runner.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import sys
import time
import traceback
from pathlib import Path
from typing import Any

REPO_ROOT = Path(os.environ.get("LATCHMOE_BASE_REPO", "/workspace/vllm-ascend-hust-LatchMoE"))
if str(REPO_ROOT) not in sys.path:
    sys.path.append(str(REPO_ROOT))

import yaml
from vllm import LLM, SamplingParams

from vllm_moe_offload_ascend import register as register_moe_offload
from benchmark.scripts.collect_moe_trace import (
    csv_set,
    load_manifest,
    prepare_sharegpt_manifest,
)
from benchmark.scripts.sharegpt_manifest import assert_no_random_dataset
from vllm_moe_offload_ascend.moe_offload.runtime import get_moe_offload_runtime, reset_moe_offload_runtime


DEFAULT_CONFIG = "benchmark/configs/sew_offload_v1.yaml"
SEW_OFFLOAD_ENV_VARS = (
    "VLLM_ASCEND_MOE_OFFLOAD_ENABLED",
    "VLLM_ASCEND_MOE_OFFLOAD_TRACE_ONLY",
    "VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS",
    "VLLM_ASCEND_MOE_OFFLOAD_POLICY",
    "VLLM_ASCEND_MOE_OFFLOAD_ASYNC_LOAD",
    "VLLM_ASCEND_MOE_OFFLOAD_MAX_PHASES",
    "VLLM_ASCEND_MOE_OFFLOAD_TRACE_MAX_RECORDS",
    "VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH",
    "VLLM_ASCEND_MOE_OFFLOAD_RESIDENT_LAYER_IDS",
    "VLLM_ASCEND_MOE_OFFLOAD_RELEASE_ORIGINAL_EXPERT_WEIGHTS",
    "VLLM_ASCEND_MOE_OFFLOAD_LAYERED_RUNTIME",
    "VLLM_ASCEND_MOE_OFFLOAD_GRAPH_COMPATIBLE",
    "VLLM_ASCEND_MOE_OFFLOAD_FANOUT_THRESHOLD",
    "VLLM_ASCEND_MOE_OFFLOAD_PROFILE_PATH",
    "VLLM_ASCEND_MOE_OFFLOAD_STAGE_SEAM",
    "VLLM_ASCEND_MOE_OFFLOAD_CPU_FIRST_LOAD",
    "VLLM_ASCEND_MOE_OFFLOAD_COMPARE_ROUTER",
    "VLLM_ASCEND_MOE_OFFLOAD_COMPARE_LAYER_BOUNDARY",
    "VLLM_ASCEND_MOE_OFFLOAD_B2_WAVE_PREFILL",
    "VLLM_ASCEND_MOE_OFFLOAD_B2_OVERFLOW_MODE",
    "VLLM_ASCEND_MOE_OFFLOAD_MAX_NUM_SEQS_HINT",
    "VLLM_ASCEND_MOE_ROUTER_PARITY_PATH",
    "VLLM_ASCEND_MOE_ROUTER_PARITY_MAX_TOKENS",
    "VLLM_ASCEND_MOE_OFFLOAD_GB",
    "VLLM_ASCEND_MOE_OFFLOAD_DIAGNOSTIC_MODE",
    "VLLM_ASCEND_MOE_OFFLOAD_SEW_DATAPLANE",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=DEFAULT_CONFIG)
    parser.add_argument(
        "--mode",
        choices=("no_offload", "trace_only", "fixed_slot_sync"),
        default="fixed_slot_sync",
        help="Single-process smoke mode. Run modes separately for correctness comparison.",
    )
    parser.add_argument("--model")
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Enable model-provided code for an explicitly scoped model oracle.",
    )
    parser.add_argument(
        "--use-chat-template",
        action="store_true",
        help="Submit each prompt as a single user chat message before generation.",
    )
    parser.add_argument(
        "--disable-thinking",
        action="store_true",
        help=(
            "Pass enable_thinking=false to the model chat template. This keeps "
            "the deterministic systems workload in non-thinking mode."
        ),
    )
    parser.add_argument(
        "--tensor-parallel-size",
        type=int,
        help=(
            "Override the model config TP size for an explicitly scoped oracle "
            "or qualification run."
        ),
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--manifest")
    parser.add_argument("--prepare-smoke-manifest", action="store_true")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--smoke-requests-per-bucket", type=int, default=1)
    parser.add_argument("--inline-prompt")
    parser.add_argument("--inline-prompts-jsonl")
    parser.add_argument("--inline-max-output-tokens", type=int, default=1)
    parser.add_argument("--override-max-output-tokens", type=int)
    parser.add_argument("--buckets", default="short_chat")
    parser.add_argument("--max-requests", type=int, default=1)
    parser.add_argument("--max-model-len", type=int, default=512)
    parser.add_argument("--max-num-seqs", type=int, default=1)
    parser.add_argument("--max-num-batched-tokens", type=int, default=512)
    parser.add_argument("--kv-cache-memory-mb", type=int, default=512)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.90)
    parser.add_argument(
        "--ascend-additional-config-json",
        default="{}",
        help=(
            "JSON object forwarded as vLLM-Ascend additional_config and recorded "
            "in the smoke summary, for example '{\"mix_placement\": true}'."
        ),
    )
    parser.add_argument(
        "--npu-profiler-dir",
        help=(
            "Optional directory for a torch_npu profiler trace of generation. "
            "Profiling starts after model load and stops when requests finish."
        ),
    )
    parser.add_argument(
        "--omit-profile-events",
        action="store_true",
        help=(
            "Keep raw moe_offload_profile.jsonl, but do not embed every raw "
            "profile event in summary.json. Useful for long formal campaigns."
        ),
    )
    parser.add_argument(
        "--continue-on-request-error",
        action="store_true",
        help=(
            "Record per-request errors instead of aborting the whole unit. "
            "Requests are submitted in --request-batch-size groups."
        ),
    )
    parser.add_argument(
        "--request-batch-size",
        type=int,
        default=1,
        help=(
            "Number of manifest requests to submit together when continuing "
            "after request errors; a failed batch falls back to per-request "
            "submission so unsupported prompts remain visible."
        ),
    )
    parser.add_argument(
        "--strict-batched-submission",
        action="store_true",
        help=(
            "Submit requests in --request-batch-size groups but abort the unit "
            "instead of retrying failed groups one request at a time. This is "
            "the fail-closed mode for concurrency exactness experiments."
        ),
    )
    parser.add_argument(
        "--disable-ascend-norm-quant-fusion",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Disable vLLM and Ascend norm-quant compiler passes for CANN compatibility probes.",
    )
    parser.add_argument(
        "--compilation-config-json",
        default="{}",
        help=(
            "Diagnostic-only JSON object merged into the generated vLLM "
            "compilation config for backend and graph-boundary controls."
        ),
    )
    parser.add_argument("--enforce-eager", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument(
        "--diagnostic-eager",
        action="store_true",
        help="Allow eager execution only for an explicitly labelled qualification diagnostic.",
    )
    parser.add_argument(
        "--ignore-eos",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Continue after an EOS token. Disabled by default to match the "
            "OpenAI chat-completion stopping rule used by the frozen workloads; "
            "enable only for explicitly labelled stress diagnostics."
        ),
    )
    parser.add_argument(
        "--output-logprobs",
        type=int,
        help=(
            "Diagnostic-only number of output-token log probabilities to "
            "record. The sampled token is always retained, so each position "
            "may contain one additional candidate."
        ),
    )
    parser.add_argument("--num-slots", type=int, default=16)
    parser.add_argument("--resident-layer-ids", default="")
    parser.add_argument("--release-original-expert-weights", action="store_true")
    parser.add_argument("--layered-runtime", action="store_true")
    parser.add_argument("--fanout-threshold", type=int, default=0)
    parser.add_argument(
        "--stage-seam",
        action="store_true",
        help="Enable the graph splitting seam for a fixed-slot qualification run.",
    )
    parser.add_argument(
        "--cpu-first-load",
        action="store_true",
        help="Load routed expert weights CPU-first before fixed-slot registration.",
    )
    parser.add_argument(
        "--router-parity",
        action="store_true",
        help="Capture bounded native and seam router snapshots in eager diagnostics.",
    )
    parser.add_argument("--router-parity-max-tokens", type=int, default=64)
    parser.add_argument(
        "--layer-boundary-parity",
        action="store_true",
        help="Compare native and seam MoE tuple outputs in eager diagnostics.",
    )
    parser.add_argument(
        "--wave-prefill",
        action="store_true",
        help="Enable the multi-wave prefill qualification path.",
    )
    parser.add_argument(
        "--async-load",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Control Main-Cache H2D/compute overlap independently of multi-wave "
            "execution. The default follows --wave-prefill; use --no-async-load "
            "for the matched serial streaming arm."
        ),
    )
    parser.add_argument("--offload-backend", default="prefetch")
    parser.add_argument(
        "--cpu-offload-gb",
        type=float,
        default=14.0,
        help="Native vLLM CPU offload budget for the explicit dynamic-address diagnostic.",
    )
    parser.add_argument("--offload-group-size", type=int, default=4)
    parser.add_argument("--offload-num-in-group", type=int, default=1)
    parser.add_argument("--offload-prefetch-step", type=int, default=1)
    parser.add_argument("--offload-params", default="experts")
    parser.add_argument(
        "--with-native-offload-backend",
        action="store_true",
        help=(
            "Engage vLLM's native offloader when explicitly requested. This "
            "is the dynamic-address diagnostic baseline in no_offload mode; "
            "it is disabled by default because SEW manages its own offloading "
            "in fixed_slot_sync mode and "
            "the native backend requires pinned CPU storage (conflicts with "
            "SEW host store, fails profile_run with 'not pinned' assertion)."
        ),
    )
    args = parser.parse_args()
    if args.request_batch_size < 1:
        parser.error("--request-batch-size must be at least 1")
    if args.output_logprobs is not None and args.output_logprobs < 1:
        parser.error("--output-logprobs must be at least 1")
    if args.strict_batched_submission and args.continue_on_request_error:
        parser.error(
            "--strict-batched-submission and --continue-on-request-error are mutually exclusive"
        )
    if args.enforce_eager and not args.diagnostic_eager:
        parser.error("--enforce-eager requires --diagnostic-eager")
    if args.diagnostic_eager and not args.enforce_eager:
        parser.error("--diagnostic-eager requires --enforce-eager")
    if args.disable_thinking and not args.use_chat_template:
        parser.error("--disable-thinking requires --use-chat-template")
    if args.stage_seam and args.mode != "fixed_slot_sync":
        parser.error("--stage-seam requires --mode fixed_slot_sync")
    if args.cpu_first_load and not args.stage_seam:
        parser.error("--cpu-first-load requires --stage-seam")
    if args.router_parity and (not args.stage_seam or not args.diagnostic_eager):
        parser.error("--router-parity requires an eager fixed-slot seam diagnostic")
    if args.layer_boundary_parity and (not args.stage_seam or not args.diagnostic_eager):
        parser.error("--layer-boundary-parity requires an eager fixed-slot seam diagnostic")
    if args.wave_prefill and not args.stage_seam:
        parser.error("--wave-prefill requires --stage-seam")
    if args.async_load is not None and not args.wave_prefill:
        parser.error("--async-load/--no-async-load requires --wave-prefill")
    try:
        args.ascend_additional_config = json.loads(
            args.ascend_additional_config_json
        )
    except json.JSONDecodeError as exc:
        parser.error(f"--ascend-additional-config-json is not valid JSON: {exc.msg}")
    if not isinstance(args.ascend_additional_config, dict):
        parser.error("--ascend-additional-config-json must decode to a JSON object")
    try:
        args.compilation_config_override = json.loads(args.compilation_config_json)
    except json.JSONDecodeError as exc:
        parser.error(f"--compilation-config-json is not valid JSON: {exc.msg}")
    if not isinstance(args.compilation_config_override, dict):
        parser.error("--compilation-config-json must decode to a JSON object")
    return args


def load_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open(encoding="utf-8") as f:
        return yaml.safe_load(f)


def make_inline_request(*, prompt: str, max_output_tokens: int) -> dict[str, Any]:
    return {
        "request_id": "inline_0000",
        "bucket": "inline",
        "prompt": prompt,
        "max_output_tokens": int(max_output_tokens),
        "temperature": 0.0,
        "top_p": 1.0,
        "dataset": "inline_smoke",
    }


def load_inline_prompts_jsonl(
    path: str | Path,
    *,
    default_max_output_tokens: int,
) -> list[dict[str, Any]]:
    requests: list[dict[str, Any]] = []
    with Path(path).open(encoding="utf-8") as f:
        for index, line in enumerate(f):
            if not line.strip():
                continue
            record = json.loads(line)
            prompt = record.get("prompt")
            if not isinstance(prompt, str) or not prompt:
                raise ValueError(f"inline prompt record {index} is missing a non-empty prompt")
            request_id = str(record.get("request_id") or f"inline_{index:04d}")
            request = make_inline_request(
                prompt=prompt,
                max_output_tokens=int(record.get("max_output_tokens", default_max_output_tokens)),
            )
            request["request_id"] = request_id
            requests.append(request)
    if not requests:
        raise ValueError(f"no inline prompts selected from {path}")
    return requests


def override_request_max_output_tokens(
    requests: list[dict[str, Any]],
    *,
    max_output_tokens: int | None,
) -> list[dict[str, Any]]:
    if max_output_tokens is None:
        return requests
    return [
        {
            **request,
            "max_output_tokens": int(max_output_tokens),
        }
        for request in requests
    ]


def configure_sew_offload_env(
    mode: str,
    *,
    num_slots: int,
    max_num_seqs_hint: int | None = None,
    resident_layer_ids: str = "",
    release_original_expert_weights: bool = False,
    layered_runtime: bool = False,
    fanout_threshold: int = 0,
    wave_prefill: bool = False,
    async_load: bool | None = None,
    trace_path: str = "moe_offload_trace.jsonl",
) -> None:
    budget_autoconfig = False
    if mode == "no_offload":
        for env_name in SEW_OFFLOAD_ENV_VARS:
            os.environ.pop(env_name, None)
        return
    elif mode == "trace_only":
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_ENABLED"] = "1"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_TRACE_ONLY"] = "1"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS"] = "0"
        # An experiment wrapper may explicitly disable raw trace output by
        # supplying an empty environment value.  Preserve that choice; the
        # default remains the per-unit trace file for standalone diagnostics.
        if "VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH" not in os.environ:
            os.environ["VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH"] = trace_path
    elif mode == "fixed_slot_sync":
        # Explicit slot smoke runs are diagnostic stress tests, not the
        # budget-mode serving contract.  When a GiB budget is also present,
        # require an explicit resident set so the test cannot silently replace
        # the parent-generated residency plan.
        budget_gib = os.getenv("VLLM_ASCEND_MOE_OFFLOAD_GB", "").strip()
        diagnostic_mode = os.getenv(
            "VLLM_ASCEND_MOE_OFFLOAD_DIAGNOSTIC_MODE", "0"
        ).strip().lower() in {"1", "true", "yes", "on"}
        budget_autoconfig = bool(
            budget_gib and not str(resident_layer_ids).strip() and diagnostic_mode
        )
        if budget_gib and not str(resident_layer_ids).strip() and not diagnostic_mode:
            raise ValueError(
                "fixed-slot diagnostic with VLLM_ASCEND_MOE_OFFLOAD_GB "
                "requires --resident-layer-ids; use budget autoconfig for "
                "production layer selection"
            )
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_DIAGNOSTIC_MODE"] = "1"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_ENABLED"] = "1"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_TRACE_ONLY"] = "0"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS"] = str(int(num_slots))
        # Keep compact slot-lease ordering evidence beside the verbose memory
        # profile. This does not change the fixed-slot dataplane.  Long
        # calibration/formal callers may explicitly disable raw trace output
        # with an empty environment value; preserve that choice.
        if "VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH" not in os.environ:
            os.environ["VLLM_ASCEND_MOE_OFFLOAD_TRACE_PATH"] = trace_path
    else:
        raise ValueError(f"unsupported smoke mode: {mode}")
    # B2 overlap requires the transfer stream to remain in flight while the
    # resident shared producer runs.  Keep the historical synchronous setting
    # for other smoke modes, but use async pinned-host staging for the matched
    # shared/H2D qualification path.
    overlap_enabled = bool(wave_prefill) if async_load is None else bool(async_load)
    os.environ["VLLM_ASCEND_MOE_OFFLOAD_ASYNC_LOAD"] = (
        "1" if overlap_enabled else "0"
    )
    os.environ["VLLM_ASCEND_MOE_OFFLOAD_MAX_PHASES"] = "1"
    if budget_autoconfig:
        # Let GiB AutoConfig publish the authoritative resident-layer set.
        os.environ.pop("VLLM_ASCEND_MOE_OFFLOAD_RESIDENT_LAYER_IDS", None)
    else:
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_RESIDENT_LAYER_IDS"] = resident_layer_ids
    os.environ["VLLM_ASCEND_MOE_OFFLOAD_RELEASE_ORIGINAL_EXPERT_WEIGHTS"] = (
        "1" if release_original_expert_weights else "0"
    )
    os.environ["VLLM_ASCEND_MOE_OFFLOAD_LAYERED_RUNTIME"] = "1" if layered_runtime else "0"
    os.environ["VLLM_ASCEND_MOE_OFFLOAD_GRAPH_COMPATIBLE"] = (
        "1" if mode == "fixed_slot_sync" else "0"
    )
    if budget_autoconfig and int(fanout_threshold) == 0:
        os.environ.pop("VLLM_ASCEND_MOE_OFFLOAD_FANOUT_THRESHOLD", None)
    else:
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_FANOUT_THRESHOLD"] = str(
            int(fanout_threshold)
        )
    if max_num_seqs_hint is not None:
        if int(max_num_seqs_hint) <= 0:
            raise ValueError("max_num_seqs_hint must be greater than zero")
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_MAX_NUM_SEQS_HINT"] = str(
            int(max_num_seqs_hint)
        )
    # The caller owns the artifact path.  ``run_smoke`` assigns the output-dir
    # scoped default after this configuration step; setting a process-CWD
    # default here would preempt it and send worker diagnostics to the
    # repository root.


def _csv_set(value: str) -> set[str]:
    return {item.strip() for item in value.split(",") if item.strip()}


def _output_records(
    outputs: list[Any],
    request_id_map: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for output in outputs:
        completion = output.outputs[0]
        token_ids = [int(token_id) for token_id in getattr(completion, "token_ids", [])]
        output_text = getattr(completion, "text", "")
        if not isinstance(output_text, str):
            output_text = ""
        engine_request_id = str(output.request_id)
        records.append(
            {
                "request_id": (request_id_map or {}).get(
                    engine_request_id, engine_request_id
                ),
                "engine_request_id": engine_request_id,
                "output_text": output_text,
                "output_token_ids": token_ids,
                "output_tokens": len(token_ids),
                "output_logprobs": _serialize_output_logprobs(
                    getattr(completion, "logprobs", None), token_ids
                ),
            }
        )
    return records


def _serialize_output_logprobs(
    positions: Any,
    sampled_token_ids: list[int],
) -> list[dict[str, Any]] | None:
    """Convert vLLM logprob objects into stable, bounded JSON records."""

    if positions is None:
        return None
    serialized: list[dict[str, Any]] = []
    for index, position in enumerate(positions):
        sampled_token_id = (
            int(sampled_token_ids[index]) if index < len(sampled_token_ids) else None
        )
        candidates: list[dict[str, Any]] = []
        if position:
            for raw_token_id, detail in position.items():
                candidates.append(
                    {
                        "token_id": int(raw_token_id),
                        "logprob": float(getattr(detail, "logprob", detail)),
                        "rank": (
                            int(detail.rank)
                            if getattr(detail, "rank", None) is not None
                            else None
                        ),
                        "decoded_token": getattr(detail, "decoded_token", None),
                    }
                )
        candidates.sort(key=lambda item: (-item["logprob"], item["token_id"]))
        selected = next(
            (
                item
                for item in candidates
                if sampled_token_id is not None
                and item["token_id"] == sampled_token_id
            ),
            None,
        )
        best_alternative = next(
            (
                item
                for item in candidates
                if sampled_token_id is None or item["token_id"] != sampled_token_id
            ),
            None,
        )
        selected_margin = (
            float(selected["logprob"] - best_alternative["logprob"])
            if selected is not None and best_alternative is not None
            else None
        )
        serialized.append(
            {
                "position": index,
                "sampled_token_id": sampled_token_id,
                "selected_logprob": selected["logprob"] if selected else None,
                "best_alternative_token_id": (
                    best_alternative["token_id"] if best_alternative else None
                ),
                "selected_vs_best_alternative_logprob_margin": selected_margin,
                "candidates": candidates,
            }
        )
    return serialized


def _write_outputs_jsonl(
    output_dir: Path,
    outputs: list[Any],
    request_id_map: dict[str, str] | None = None,
) -> None:
    records = _output_records(outputs, request_id_map=request_id_map)
    with (output_dir / "outputs.jsonl").open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _write_output_records_jsonl(output_dir: Path, records: list[dict[str, Any]]) -> None:
    with (output_dir / "outputs.jsonl").open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def _read_profile_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                events.append(json.loads(line))
    return events


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    k = (len(ordered) - 1) * percentile / 100
    lo = int(k)
    hi = min(lo + 1, len(ordered) - 1)
    if lo == hi:
        return ordered[lo]
    weight = k - lo
    return ordered[lo] * (1 - weight) + ordered[hi] * weight


def _summarize(values: list[float]) -> dict[str, float]:
    if not values:
        return {"mean": 0.0, "median": 0.0, "p90": 0.0}
    return {
        "mean": statistics.fmean(values),
        "median": statistics.median(values),
        "p90": _percentile(values, 90),
    }


def _smoke_compilation_config(
    *,
    mode: str,
    enforce_eager: bool,
    disable_ascend_norm_quant_fusion: bool,
    override: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    config: dict[str, Any] = {}
    if mode == "fixed_slot_sync" and not enforce_eager:
        config["cudagraph_mode"] = "PIECEWISE"
    if disable_ascend_norm_quant_fusion:
        config["pass_config"] = {"fuse_norm_quant": False}
    for key, value in (override or {}).items():
        if key == "pass_config" and isinstance(value, dict):
            config["pass_config"] = {
                **dict(config.get("pass_config") or {}),
                **value,
            }
        else:
            config[key] = value
    return config or None


def _metrics_from_outputs(
    outputs: list[Any],
    duration_s: float,
    request_id_map: dict[str, str] | None = None,
    output_request_ids: list[str] | None = None,
) -> dict[str, Any]:
    total_output_tokens = 0
    ttfts_ms: list[float] = []
    tpots_ms: list[float] = []
    per_request: list[dict[str, Any]] = []
    for output_index, output in enumerate(outputs):
        completion = output.outputs[0]
        num_tokens = len(completion.token_ids)
        total_output_tokens += num_tokens
        request_metrics = getattr(output, "metrics", None)
        if request_metrics is None or num_tokens < 1:
            raise ValueError('Missing request metrics or empty generated output')
        ttft_ms = float(getattr(request_metrics, 'first_token_latency', float('nan'))) * 1000
        first_token_ts = getattr(request_metrics, 'first_token_ts', None)
        last_token_ts = getattr(request_metrics, 'last_token_ts', None)
        if not math.isfinite(ttft_ms) or ttft_ms <= 0:
            raise ValueError('Missing/nonfinite/nonpositive TTFT')
        tpot_ms = None
        if num_tokens > 1:
            if first_token_ts is None or last_token_ts is None:
                raise ValueError('Missing output-token timestamps')
            interval_ms = float(last_token_ts-first_token_ts)*1000
            if not math.isfinite(interval_ms) or interval_ms <= 0:
                raise ValueError('Invalid output-token interval')
            tpot_ms = interval_ms/(num_tokens-1)
        ttfts_ms.append(ttft_ms)
        if num_tokens > 1:
            tpots_ms.append(tpot_ms)
        per_request.append(
            {
                "request_id": (
                    output_request_ids[output_index]
                    if output_request_ids is not None and output_index < len(output_request_ids)
                    else (request_id_map or {}).get(str(output.request_id), str(output.request_id))
                ),
                "engine_request_id": str(output.request_id),
                "output_tokens": num_tokens,
                "ttft_ms": ttft_ms,
                "tpot_ms": tpot_ms,
                "first_token_ts": first_token_ts,
                "last_token_ts": last_token_ts,
                "request_stream_ms": ttft_ms + ((num_tokens-1)*tpot_ms if tpot_ms is not None else 0),
            }
        )
    return {
        "duration_s": duration_s,
        "completed": len(outputs),
        "total_output_tokens": total_output_tokens,
        "output_throughput_tok_s": total_output_tokens / duration_s if duration_s else 0.0,
        "ttft_ms": _summarize(ttfts_ms),
        "tpot_ms": _summarize(tpots_ms) if tpots_ms else None,
        "per_request": per_request,
    }


def _build_llm_kwargs(args: argparse.Namespace, config: dict[str, Any], mode: str) -> dict[str, Any]:
    model_path = args.model or config["model"]["path"]
    requested_tp = getattr(args, "tensor_parallel_size", None)
    tensor_parallel_size = int(
        requested_tp
        if requested_tp is not None
        else config["model"]["tensor_parallel_size"]
    )
    if tensor_parallel_size <= 0:
        raise ValueError("tensor_parallel_size must be greater than zero")
    kwargs: dict[str, Any] = {
        "model": model_path,
        "tensor_parallel_size": tensor_parallel_size,
        "trust_remote_code": bool(getattr(args, "trust_remote_code", False)),
        "dtype": "bfloat16",
        "enforce_eager": bool(getattr(args, "enforce_eager", False)),
        "gpu_memory_utilization": float(getattr(args, "gpu_memory_utilization", 0.9)),
        "kv_cache_memory_bytes": int(getattr(args, "kv_cache_memory_mb", 0)) * 1024 * 1024,
        "max_model_len": int(getattr(args, "max_model_len", 4096)),
        "max_num_seqs": int(getattr(args, "max_num_seqs", 1)),
        "max_num_batched_tokens": int(getattr(args, "max_num_batched_tokens", 0)),
        "enable_expert_parallel": False,
        "seed": int(config["dataset"]["seed"]),
        "disable_log_stats": False,
        "enable_prefix_caching": False,
    }
    if mode in {"no_offload", "fixed_slot_sync"} and getattr(
        args, "with_native_offload_backend", False
    ):
        # SEW manages its own offloading via host store + slot bank + original
        # weight release. The native vLLM offloader is a separate system that
        # requires pinned CPU storage and conflicts with SEW when both manage
        # experts (it fails in profile_run with "CPU storage ... is not pinned").
        # Only engage it when explicitly opted in.
        kwargs.update(
            {
                "cpu_offload_gb": float(args.cpu_offload_gb),
                "offload_backend": args.offload_backend,
                "offload_group_size": args.offload_group_size,
                "offload_num_in_group": args.offload_num_in_group,
                "offload_prefetch_step": args.offload_prefetch_step,
                "offload_params": _csv_set(args.offload_params),
            }
        )
    additional_config = dict(getattr(args, "ascend_additional_config", {}) or {})
    disable_norm_quant = bool(getattr(args, "disable_ascend_norm_quant_fusion", False))
    if disable_norm_quant:
        compile_config = dict(
            additional_config.get("ascend_compilation_config") or {}
        )
        compile_config["fuse_norm_quant"] = False
        additional_config["ascend_compilation_config"] = compile_config
    if additional_config:
        kwargs["additional_config"] = additional_config
    npu_profiler_dir = getattr(args, "npu_profiler_dir", None)
    if npu_profiler_dir:
        kwargs["profiler_config"] = {
            "profiler": "torch",
            "torch_profiler_dir": str(Path(npu_profiler_dir).resolve()),
            # Stack collection makes full-model traces needlessly large and is
            # not needed to establish NPU stream overlap.
            "torch_profiler_with_stack": False,
            "ignore_frontend": True,
        }
    compilation_config = _smoke_compilation_config(
        mode=mode,
        enforce_eager=bool(getattr(args, "enforce_eager", False)),
        disable_ascend_norm_quant_fusion=disable_norm_quant,
        override=dict(getattr(args, "compilation_config_override", {}) or {}),
    )
    if compilation_config is not None:
        kwargs["compilation_config"] = compilation_config
    return kwargs


def worker_evidence(worker, reset=False):
    import hashlib
    import torch
    import vllm_moe_offload_ascend as package
    from vllm_moe_offload_ascend.moe_offload.runtime import get_moe_offload_runtime
    runtime = get_moe_offload_runtime()
    torch.npu.synchronize()
    if reset:
        torch.npu.reset_peak_memory_stats()
        runtime._rebuild_audit = {"stages": 0, "hits": 0, "misses": 0, "h2d_bytes": 0,
                                  "waves": 0, "digest": hashlib.sha256()}
    audit = dict(getattr(runtime, "_rebuild_audit", {}))
    if "digest" in audit:
        audit["digest"] = audit["digest"].hexdigest()
    return {"allocated_bytes": torch.npu.memory_allocated(),
            "reserved_bytes": torch.npu.memory_reserved(),
            "peak_allocated_bytes": torch.npu.max_memory_allocated(),
            "peak_reserved_bytes": torch.npu.max_memory_reserved(),
            "managed_memory_ledger": runtime.memory_ledger().to_jsonable(),
            "audit": audit, "package_file": package.__file__}


def run_smoke(
    args: argparse.Namespace,
    config: dict[str, Any],
    requests: list[dict[str, Any]],
) -> dict[str, Any]:
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    profile_jsonl_path = output_dir / "moe_offload_profile.jsonl"
    trace_jsonl_path = output_dir / "moe_offload_trace.jsonl"
    if profile_jsonl_path.exists():
        profile_jsonl_path.unlink()
    if trace_jsonl_path.exists():
        trace_jsonl_path.unlink()
    mode = getattr(args, "mode", "fixed_slot_sync")
    configure_sew_offload_env(
        mode,
        num_slots=args.num_slots,
        max_num_seqs_hint=(
            int(args.max_num_seqs)
            if bool(getattr(args, "wave_prefill", False))
            else None
        ),
        resident_layer_ids=getattr(args, "resident_layer_ids", ""),
        release_original_expert_weights=getattr(args, "release_original_expert_weights", False),
        layered_runtime=getattr(args, "layered_runtime", False),
        fanout_threshold=getattr(args, "fanout_threshold", 0),
        wave_prefill=bool(getattr(args, "wave_prefill", False)),
        async_load=getattr(args, "async_load", None),
        trace_path=str(trace_jsonl_path),
    )
    router_parity_path = output_dir / "moe_router_parity.jsonl"
    if bool(getattr(args, "stage_seam", False)):
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_STAGE_SEAM"] = "1"
    if bool(getattr(args, "cpu_first_load", False)):
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_CPU_FIRST_LOAD"] = "1"
    if bool(getattr(args, "router_parity", False)):
        if router_parity_path.exists():
            router_parity_path.unlink()
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_COMPARE_ROUTER"] = "1"
        os.environ["VLLM_ASCEND_MOE_ROUTER_PARITY_PATH"] = str(router_parity_path)
        os.environ["VLLM_ASCEND_MOE_ROUTER_PARITY_MAX_TOKENS"] = str(
            max(1, int(getattr(args, "router_parity_max_tokens", 64)))
        )
    if bool(getattr(args, "layer_boundary_parity", False)):
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_COMPARE_LAYER_BOUNDARY"] = "1"
    if bool(getattr(args, "wave_prefill", False)):
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_B2_WAVE_PREFILL"] = "1"
        os.environ["VLLM_ASCEND_MOE_OFFLOAD_B2_OVERFLOW_MODE"] = "multi_wave"
    if mode != "no_offload":
        # Empty means "do not profile" for long calibration/formal campaigns.
        # Keep the historical output-file default when the caller did not
        # provide an explicit value.
        if "VLLM_ASCEND_MOE_OFFLOAD_PROFILE_PATH" not in os.environ:
            os.environ["VLLM_ASCEND_MOE_OFFLOAD_PROFILE_PATH"] = str(profile_jsonl_path)
        # vLLM selects a single platform plugin; explicitly install LatchMoE hooks.
        register_moe_offload()
    reset_moe_offload_runtime()

    llm_kwargs = _build_llm_kwargs(args, config, mode)
    llm_kwargs["worker_extension_cls"] = "wave_worker.WaveWorkerExtension"
    load_t0 = time.perf_counter()
    llm = LLM(**llm_kwargs)
    load_s = time.perf_counter() - load_t0
    worker_before = llm.collective_rpc("get_rebuild_evidence", timeout=180, kwargs={"reset": True})
    (output_dir / "worker_before.json").write_text(json.dumps(worker_before, indent=2))

    sampling_params = [
        SamplingParams(
            max_tokens=int(req["max_output_tokens"]),
            temperature=float(req.get("temperature", 0.0)),
            top_p=float(req.get("top_p", 1.0)),
            seed=int(req.get("seed", config["dataset"]["seed"])),
            ignore_eos=args.ignore_eos,
            logprobs=getattr(args, "output_logprobs", None),
        )
        for req in requests
    ]
    # vLLM's in-process LLM API assigns positional engine request IDs ("0",
    # "1", ...), which are not the provenance IDs in our dataset manifest.
    # Preserve both IDs so concurrency audits can join outputs back to the
    # immutable workload records instead of silently treating a position as a
    # user request identity.
    request_id_map = {
        str(index): str(request.get("request_id", index))
        for index, request in enumerate(requests)
    }
    profiler_dir = getattr(args, "npu_profiler_dir", None)
    profiler_started = False
    if profiler_dir:
        Path(profiler_dir).mkdir(parents=True, exist_ok=True)
        llm.start_profile("latchmoe")
        profiler_started = True
    gen_t0 = time.perf_counter()
    request_errors: list[dict[str, Any]] = []
    completed_request_ids: list[str] = []
    output_records: list[dict[str, Any]] = []
    output_request_ids: list[str] = []
    submission_batches: list[dict[str, Any]] = []

    request_call_times = {}

    def _generate_request_group(
        group_requests: list[dict[str, Any]],
        group_sampling_params: list[SamplingParams],
    ) -> list[Any]:
        if bool(getattr(args, "use_chat_template", False)):
            return llm.chat(
                [
                    [{"role": "user", "content": str(request["prompt"])}]
                    for request in group_requests
                ],
                group_sampling_params,
                use_tqdm=False,
                chat_template_kwargs=(
                    {"enable_thinking": False}
                    if bool(getattr(args, "disable_thinking", False))
                    else None
                ),
            )
        return llm.generate(
            [request["prompt"] for request in group_requests],
            group_sampling_params,
            use_tqdm=False,
        )

    def generate_request_group(group_requests, group_sampling_params):
        if len(group_requests) != 1:
            raise ValueError('Q1 timing requires sequential single-request calls')
        start_ns = time.perf_counter_ns()
        group_outputs = _generate_request_group(group_requests, group_sampling_params)
        end_ns = time.perf_counter_ns()
        rid = str(group_requests[0]['request_id'])
        request_call_times[rid] = {'start_perf_ns': start_ns, 'end_perf_ns': end_ns,
                                 'request_call_ms': (end_ns-start_ns)/1e6}
        with (output_dir/'request_call_times.jsonl').open('a') as handle:
            handle.write(json.dumps({'request_id': rid, **request_call_times[rid]})+'\n')
        print('Q1_REQUEST_COMPLETE '+json.dumps({'request_id':rid,'completed':len(request_call_times),
                   'output_tokens':len(group_outputs[0].outputs[0].token_ids)}),flush=True)
        return group_outputs

    def record_request_group(
        group_requests: list[dict[str, Any]],
        group_outputs: list[Any],
        *,
        batch_index: int,
        manifest_positions: list[int],
        fallback: bool = False,
    ) -> None:
        if len(group_outputs) != len(group_requests):
            raise RuntimeError(
                "engine returned "
                f"{len(group_outputs)} outputs for {len(group_requests)} requests"
            )
        for batch_position, (request, output, manifest_position) in enumerate(
            zip(group_requests, group_outputs, manifest_positions)
        ):
            request_id = str(request.get("request_id", ""))
            records = _output_records(
                [output],
                request_id_map={str(output.request_id): request_id},
            )
            records[0].update(
                {
                    "manifest_position": int(manifest_position),
                    "submission_batch_index": int(batch_index),
                    "submission_batch_position": int(batch_position),
                    "per_request_fallback": bool(fallback),
                }
            )
            output_records.extend(records)
            completed_request_ids.append(request_id)
            output_request_ids.append(request_id)

    try:
        grouped_submission = bool(
            getattr(args, "continue_on_request_error", False)
            or getattr(args, "strict_batched_submission", False)
        )
        if grouped_submission:
            outputs = []
            request_batch_size = max(
                1, int(getattr(args, "request_batch_size", 1))
            )
            for batch_start in range(0, len(requests), request_batch_size):
                batch_index = batch_start // request_batch_size
                batch_requests = requests[batch_start : batch_start + request_batch_size]
                batch_sampling_params = sampling_params[
                    batch_start : batch_start + request_batch_size
                ]
                manifest_positions = list(
                    range(batch_start, batch_start + len(batch_requests))
                )
                batch_record = {
                    "batch_index": int(batch_index),
                    "manifest_positions": manifest_positions,
                    "request_ids": [
                        str(request.get("request_id", ""))
                        for request in batch_requests
                    ],
                    "size": len(batch_requests),
                    "strict": bool(
                        getattr(args, "strict_batched_submission", False)
                    ),
                    "fallback_used": False,
                }
                submission_batches.append(batch_record)
                try:
                    group_outputs = generate_request_group(
                        batch_requests, batch_sampling_params
                    )
                    record_request_group(
                        batch_requests,
                        group_outputs,
                        batch_index=batch_index,
                        manifest_positions=manifest_positions,
                    )
                    outputs.extend(group_outputs)
                    batch_record["status"] = "completed"
                except Exception as batch_exc:
                    batch_record["status"] = "failed"
                    batch_record["error_type"] = type(batch_exc).__name__
                    batch_record["error"] = str(batch_exc)
                    if bool(getattr(args, "strict_batched_submission", False)):
                        raise
                    # Context-limit failures can reject an entire batch. Retry
                    # its members individually so supported requests still
                    # contribute to the exact-token coverage denominator.
                    batch_record["fallback_used"] = True
                    for request, sampling_param, manifest_position in zip(
                        batch_requests, batch_sampling_params, manifest_positions
                    ):
                        request_id = str(request.get("request_id", ""))
                        try:
                            one_outputs = generate_request_group(
                                [request], [sampling_param]
                            )
                            record_request_group(
                                [request],
                                one_outputs,
                                batch_index=batch_index,
                                manifest_positions=[manifest_position],
                                fallback=True,
                            )
                            outputs.extend(one_outputs)
                        except Exception as exc:
                            request_errors.append(
                                {
                                    "request_id": request_id,
                                    "error_type": type(exc).__name__,
                                    "error": str(exc),
                                }
                            )
        else:
            submission_batches.append(
                {
                    "batch_index": 0,
                    "manifest_positions": list(range(len(requests))),
                    "request_ids": [
                        str(request.get("request_id", ""))
                        for request in requests
                    ],
                    "size": len(requests),
                    "strict": False,
                    "fallback_used": False,
                    "status": "completed",
                }
            )
            outputs = generate_request_group(requests, sampling_params)
    finally:
        if profiler_started:
            llm.stop_profile()
    gen_s = time.perf_counter() - gen_t0
    worker_after = llm.collective_rpc("get_rebuild_evidence", timeout=60)
    (output_dir / "worker_after.json").write_text(json.dumps(worker_after, indent=2))

    if bool(
        getattr(args, "continue_on_request_error", False)
        or getattr(args, "strict_batched_submission", False)
    ):
        _write_output_records_jsonl(output_dir, output_records)
    else:
        _write_outputs_jsonl(output_dir, outputs, request_id_map=request_id_map)
    summary = _metrics_from_outputs(
        outputs,
        gen_s,
        request_id_map=request_id_map,
        output_request_ids=output_request_ids or None,
    )
    for row in summary['per_request']:
        row.update(request_call_times[row['request_id']])
    summary['request_call_ms'] = _summarize([r['request_call_ms'] for r in summary['per_request']])
    summary['request_stream_ms'] = _summarize([r['request_stream_ms'] for r in summary['per_request']])
    summary.update(
        {
            "status": "partial" if request_errors else "ok",
            "mode": mode,
            "diagnostic_mode": bool(
                os.environ.get("VLLM_ASCEND_MOE_OFFLOAD_DIAGNOSTIC_MODE", "0")
                == "1"
            ),
            "model": llm_kwargs["model"],
            "tensor_parallel_size": int(llm_kwargs["tensor_parallel_size"]),
            "trust_remote_code": bool(llm_kwargs.get("trust_remote_code", False)),
            "use_chat_template": bool(getattr(args, "use_chat_template", False)),
            "disable_thinking": bool(getattr(args, "disable_thinking", False)),
            "ignore_eos": bool(getattr(args, "ignore_eos", False)),
            "execution_mode": "eager" if bool(args.enforce_eager) else "graph",
            "storage_protocol": (
                "dynamic_address_native_prefetch"
                if mode == "no_offload" and getattr(args, "with_native_offload_backend", False)
                else "full_resident_native"
                if mode == "no_offload"
                else "stable_slot_latchmoe"
            ),
            "native_offload_backend": (
                args.offload_backend
                if getattr(args, "with_native_offload_backend", False)
                else None
            ),
            "native_offload_enabled": bool(
                getattr(args, "with_native_offload_backend", False)
            ),
            "num_slots": int(args.num_slots) if mode == "fixed_slot_sync" else 0,
            "layered_runtime": bool(getattr(args, "layered_runtime", False)) if mode == "fixed_slot_sync" else False,
            "graph_compatible_offload": bool(
                mode == "fixed_slot_sync"
            ),
            "fanout_threshold": int(getattr(args, "fanout_threshold", 0)) if mode == "fixed_slot_sync" else 0,
            "disable_ascend_norm_quant_fusion": bool(
                getattr(args, "disable_ascend_norm_quant_fusion", False)
            ),
            "ascend_additional_config": llm_kwargs.get("additional_config", {}),
            "npu_profiler_dir": (
                str(Path(profiler_dir).resolve()) if profiler_dir else None
            ),
            "load_seconds": load_s,
            "manifest": str(args.manifest),
            "buckets": args.buckets,
            "request_id_map": request_id_map,
            "requested_request_ids": [
                str(request.get("request_id", index))
                for index, request in enumerate(requests)
            ],
            "completed_request_ids": completed_request_ids,
            "failed_requests": request_errors,
            "failed_request_count": len(request_errors),
            "request_batch_size": int(getattr(args, "request_batch_size", 1)),
            "request_submission_mode": (
                "batched_with_per_request_fallback"
                if bool(getattr(args, "continue_on_request_error", False))
                else "strict_batched"
                if bool(getattr(args, "strict_batched_submission", False))
                else "single_engine_call"
            ),
            "request_error_policy": (
                "continue_and_record"
                if bool(getattr(args, "continue_on_request_error", False))
                else "abort_unit"
            ),
            "output_logprobs": getattr(args, "output_logprobs", None),
            "async_load": os.environ.get(
                "VLLM_ASCEND_MOE_OFFLOAD_ASYNC_LOAD",
                "0",
            ) == "1",
            "submission_batches": submission_batches,
            "moe_offload_profile": get_moe_offload_runtime().profiling_summary(),
            "moe_offload_profile_jsonl": str(profile_jsonl_path),
            "moe_offload_profile_jsonl_events": (
                []
                if bool(getattr(args, "omit_profile_events", False))
                else _read_profile_jsonl(profile_jsonl_path)
            ),
            "profile_events_embedded": not bool(
                getattr(args, "omit_profile_events", False)
            ),
            "qualification_diagnostics": {
                "diagnostic_eager": bool(getattr(args, "diagnostic_eager", False)),
                "stage_seam": bool(getattr(args, "stage_seam", False)),
                "cpu_first_load": bool(getattr(args, "cpu_first_load", False)),
                "release_original_expert_weights": bool(
                    getattr(args, "release_original_expert_weights", False)
                ),
                "graph_compatible_offload": bool(mode == "fixed_slot_sync"),
                "router_parity": bool(getattr(args, "router_parity", False)),
                "router_parity_artifact": (
                    str(router_parity_path)
                    if bool(getattr(args, "router_parity", False))
                    else None
                ),
                "layer_boundary_parity": bool(
                    getattr(args, "layer_boundary_parity", False)
                ),
                "wave_prefill": bool(getattr(args, "wave_prefill", False)),
                "async_load": os.environ.get(
                    "VLLM_ASCEND_MOE_OFFLOAD_ASYNC_LOAD",
                    "0",
                ) == "1",
                "ascend_additional_config": llm_kwargs.get(
                    "additional_config", {}
                ),
                "compilation_config_override": dict(
                    getattr(args, "compilation_config_override", {}) or {}
                ),
            },
        }
    )
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def run_fixed_slot_smoke(
    args: argparse.Namespace,
    config: dict[str, Any],
    requests: list[dict[str, Any]],
) -> dict[str, Any]:
    args.mode = "fixed_slot_sync"
    return run_smoke(args, config, requests)


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    config = load_config(args.config)
    assert_no_random_dataset(config)
    selected_buckets = csv_set(args.buckets) or None
    manifest_path = Path(args.manifest or config["dataset"]["manifest_path"])
    args.manifest = str(manifest_path)

    if args.prepare_smoke_manifest:
        prepare_sharegpt_manifest(
            config=config,
            manifest_path=manifest_path,
            requests_per_bucket=args.smoke_requests_per_bucket,
            buckets=selected_buckets,
            model_path=args.model,
        )
        if args.prepare_only:
            print(f"PREPARE_OK manifest={manifest_path}", flush=True)
            return

    try:
        if args.inline_prompts_jsonl is not None:
            requests = load_inline_prompts_jsonl(
                args.inline_prompts_jsonl,
                default_max_output_tokens=args.inline_max_output_tokens,
            )
        elif args.inline_prompt is not None:
            requests = [
                make_inline_request(
                    prompt=args.inline_prompt,
                    max_output_tokens=args.inline_max_output_tokens,
                )
            ]
        else:
            requests = load_manifest(manifest_path, selected_buckets, args.max_requests)
        requests = override_request_max_output_tokens(
            requests,
            max_output_tokens=args.override_max_output_tokens,
        )
        summary = run_smoke(args, config, requests)
        print("SMOKE_SUMMARY " + json.dumps(summary, ensure_ascii=False), flush=True)
    except BaseException as exc:
        failure = {
            "status": "failed",
            "mode": args.mode,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "manifest": str(manifest_path),
            "num_slots": int(args.num_slots),
        }
        (output_dir / "summary.json").write_text(json.dumps(failure, indent=2), encoding="utf-8")
        print(f"SMOKE_FAILED {type(exc).__name__}: {exc}", flush=True)
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()
