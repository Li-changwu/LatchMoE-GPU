# 已完成：Q1 缺失实验与稳定性复测

2026-09-14，已通过 ssh lcw-91 补齐 HumanEval、GSM8K 两模型三方法共 12 组；保留原服务器已经完成的 ShareGPT 六组。主矩阵 18/18 组、360 条正式请求均成功，12 项成对比较中的 240 条请求输出逐 token 完全一致。analysis.json 的 complete=true、valid=true，无缺失、无错误、无待完成质量检查。

最新 LatchMoE 为统一整理 token、固定容量 overflow 批次图重放及原 Decode 图。BF16、不量化，模型权重不变。每数据集沿用原固定 20 条 Prompt，最大生成 128 token，允许 EOS；三方法固定同一模型/数据集的服务器、NPU 和 NUMA。ShareGPT 来自原服务器，HumanEval/GSM8K 来自 lcw-91；共享服务器与两台物理服务器的限制已披露。

本次补测相对同策略异步 Eager 的完整请求速度比：Qwen HumanEval 2.367 倍、GSM8K 2.325 倍；GLM HumanEval 2.072 倍、GSM8K 1.867 倍。TTFT 也有所改善，但仍慢于 Native；完整加速包含 Prefill 和 Decode 的共同差异，不能全部归因于新增 Prefill 图。

GLM HumanEval Native 的预定完整复测已通过；20 条输出与首次运行完全一致，逐请求 TPOT 为 557.56–557.74 ms，中位数漂移约 0.0381%。主矩阵使用 glm_humaneval_native_lcw91_stability_r1，首次异常运行全部保留。详见 STABILITY.zh.md，未删除慢请求或拼接部分结果。

两条有限主队列和最后复测均已结束，本任务无活动实验进程，无后续自动任务。NPU6/7 的本任务占用已释放；未停止其他作业。两个锁定运行库的提交未变化，工作树干净。核验器 12 个合成场景通过；硬件资格检查、正式输出检查与这些 CPU 测试分别保存。

交付：RESULTS.zh.md、results.csv、analysis.json；三张图的 PDF/SVG/PNG；全部逐请求输出、墙钟耗时、源码/工作量摘要、缓存与搬运审计、图执行和内存证据。图表已视觉检查，独立存放；未覆盖原论文文本、图表或旧实验结果。原暂停、迁移、运行过程记录见 STATUS.history.zh.md。
