"""Package validated Q1 evidence, with per-file checksums and no external symlinks."""
import hashlib
import json
from pathlib import Path
import zipfile
from analyze_campaign import analyze

ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    result=analyze(ROOT)
    assert result['valid'], 'Final experiment and stability checks must pass before export'
    archive=ROOT/'q1_evidence_20260914.zip'
    temporary=ROOT/'q1_evidence_20260914.zip.tmp'
    excluded={archive.name,temporary.name,'evidence_manifest.json','evidence_archive.json'}
    paths=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and not p.is_symlink()
           and '__pycache__' not in p.parts and p.name not in excluded]
    files={p.relative_to(ROOT).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                                        'bytes':p.stat().st_size} for p in paths}
    manifest={'primary_runs':[u['name'] for u in result['units']],
              'matched_comparisons':len(result['comparisons']),
              'matched_requests':sum(c['exact_match_requests'] for c in result['comparisons']),
              'files':files}
    manifest_path=ROOT/'evidence_manifest.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in paths+[manifest_path]:
            z.write(p,p.relative_to(ROOT).as_posix())
    temporary.replace(archive)
    metadata={'archive':archive.name,'bytes':archive.stat().st_size,
              'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)+1}
    (ROOT/'evidence_archive.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(metadata))
