"""Explicitly invoked full matrix; qualification must complete first."""
import argparse
import concurrent.futures
import json
from pathlib import Path
from run_job import ROOT,run,save,digest

def qualification(model):
    candidates=[]
    critical=[ROOT/name for name in ('runner.py','wave_worker.py','wave_executor.py')]
    critical+=list((ROOT/'overlay').rglob('*.py'))
    expected={str(p.relative_to(ROOT)):digest(p) for p in critical}
    for p in (ROOT/'runs').glob(f'qualify_{model}_sg*/unit.json'):
        u=json.loads(p.read_text())
        if u.get('status')=='complete' and u.get('verify'):
            if any(u.get('source_hashes',{}).get(k)!=v for k,v in expected.items()):
                continue
            worker=json.loads((p.parent/'worker_after.json').read_text())[0]
            summary=json.loads((p.parent/'summary.json').read_text())
            arena=worker['wave_reuse']['arena']
            if (summary.get('status')=='ok' and summary.get('completed')==u['requests']
                and worker['wave_reuse']['decode_addresses_unchanged']
                and arena and arena['verified']>0 and arena['verified_layers']>0
                and arena['max_error']==0 and arena['fallbacks']==0
                and arena['replays']>0 and arena['graphs']>0):
                candidates.append(str(p.parent))
    if not candidates:
        raise RuntimeError(f'{model}: no completed, verified graph qualification; campaign not started')
    return candidates

def lane(model):
    orders=[('latchmoe','eager','native'),('native','latchmoe','eager'),('eager','native','latchmoe')]
    results=[]
    for dataset,arms in zip(('sharegpt','humaneval','gsm8k'),orders):
        for arm in arms:
            name=f'{model}_{dataset}_{arm}_r1'
            prior=ROOT/'runs'/name/'unit.json'
            if prior.exists():
                result=json.loads(prior.read_text())
                if result['status']!='complete':
                    raise RuntimeError(f'Unfinished/failed result preserved: {name}; resolve explicitly before resume')
            else:
                result=run({'name':name,'model':model,'dataset':dataset,'arm':arm,'requests':20,'verify':False})
            results.append(result)
            save(ROOT/f'campaign_{model}_progress.json',results)
            if result['status']!='complete':
                raise RuntimeError(f'Failed unit: {name}; no later units launched in this model lane')
    return results

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--model',choices=['qwen','glm','both'],default='both')
    p.add_argument('--parallel-models',action='store_true')
    a=p.parse_args()
    models=['qwen','glm'] if a.model=='both' else [a.model]
    gates={m:qualification(m) for m in models}
    save(ROOT/'campaign_qualification_gate.json',gates)
    if a.parallel_models:
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(models)) as pool:
            results=list(pool.map(lane,models))
    else:
        results=[lane(m) for m in models]
    save(ROOT/'campaign_complete.json',{'status':'complete','models':models,'results':results})
