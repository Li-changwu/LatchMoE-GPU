"""Record migrated files, stopped old work, runtime versions, and hardware."""
from datetime import datetime,timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def command(*args):
    r=subprocess.run(args,capture_output=True,text=True)
    return {'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
report={'checked_utc':datetime.now(timezone.utc).isoformat(),'ssh_alias':'lcw-91',
        'versions':{},'old_units':[],'hardware':{},'source_comparisons':[]}
for package in ('torch','torch-npu','transformers','safetensors','vllm','vllm-ascend'):
    try: report['versions'][package]=importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError: report['versions'][package]=None
for model in ('qwen','glm'):
    for dataset in ('sharegpt','humaneval','gsm8k'):
        for arm in ('latchmoe','eager','native'):
            p=root/'runs'/f'{model}_{dataset}_{arm}_r1'/'unit.json'
            if not p.exists(): continue
            u=json.loads(p.read_text())
            pid=u.get('pid');proc=Path(f'/proc/{pid}/cmdline')
            report['old_units'].append({'name':u['name'],'recorded_status':u['status'],'pid':pid,
                'current_command':proc.read_bytes().replace(b'\0',b' ').decode(errors='replace') if proc.exists() else None,
                'has_summary':(p.parent/'summary.json').exists(),'has_outputs':(p.parent/'outputs.jsonl').exists()})
            if dataset=='sharegpt':
                critical={k:v for k,v in u['source_hashes'].items() if k in ('runner.py','wave_worker.py','wave_executor.py') or k.startswith('overlay/')}
                changed=[k for k,v in critical.items() if sha(root/k)!=v]
                report['source_comparisons'].append({'unit':u['name'],'changed_critical_files':changed,
                    'manifest_unchanged':sha(Path(u['manifest']))==u['manifest_sha256']})
report['hardware']['uname']=command('uname','-a')
report['hardware']['cpu']=command('lscpu')
report['hardware']['numa']=command('numactl','--hardware')
report['hardware']['npu']=command('npu-smi','info')
report['hardware']['pci_numa']={p:(Path('/sys/bus/pci/devices')/p/'numa_node').read_text().strip()
    for p in ('0000:82:00.0','0000:42:00.0')}
report['packages_configs_sha256']={str(p):sha(p) for p in [
    Path('/root/data/shared_models/strict-models/Qwen3-30B-A3B/config.json'),
    Path('/workspace/shared_models/strict-models/GLM-4.7-Flash/config.json')]}
(root/'migration_lcw91_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('checked_utc','versions','old_units','source_comparisons')}))
