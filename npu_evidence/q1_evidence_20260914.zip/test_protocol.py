"""CPU-only invariants for C5/C32 row plans and immutable Q1 prompts."""
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from wave_executor import BUCKETS, MAX_PAIRS, build_index_plan

root=Path(__file__).resolve().parent
audit=json.loads((root/'manifest_audit.json').read_text())
rng=np.random.default_rng(20260914)
plans=0
for capacity,experts in [(5,64),(32,128)]:
    for _ in range(300):
        counts={int(e):int(rng.integers(1,51)) for e in rng.choice(experts,size=int(rng.integers(1,experts+1)),replace=False)}
        group=tuple(int(e) for e in rng.choice(list(counts),size=min(capacity,len(counts)),replace=False))
        slots=rng.choice(capacity,size=len(group),replace=False)
        physical=dict(zip(group,map(int,slots)))
        actual=sum(counts[e] for e in group)
        bucket=next(b for b in BUCKETS if b>=actual)
        indices,histogram,n=build_index_plan(counts,group,physical,capacity,bucket,MAX_PAIRS)
        expected=[]
        start=0
        positions={}
        for expert in sorted(counts):
            positions[expert]=list(range(start,start+counts[expert]))
            start+=counts[expert]
        for expert in sorted(group,key=physical.get):
            expected.extend(positions[expert])
        assert indices[:actual].tolist()==expected
        assert len(set(expected))==len(expected) and n==actual
        assert np.all(indices[actual:]==MAX_PAIRS)
        assert int(histogram.sum())==bucket
        for s in range(capacity):
            expected_count=sum(counts[e] for e in group if physical[e]==s)
            if s==capacity-1: expected_count+=bucket-actual
            assert histogram[s]==expected_count
        plans+=1
    for bucket in BUCKETS:
        warm=[bucket//capacity]*capacity
        warm[-1]+=bucket%capacity
        assert sum(warm)==bucket and all(n>=0 for n in warm)

manifest_checks=0
prompt_sets={}
for model in ('qwen','glm'):
    source=root/'manifests'/f'{model}_source_original.jsonl.gz'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==audit[model]['source_sha256']
    original=[json.loads(s) for s in gzip.decompress(source.read_bytes()).decode().split('\n') if s.strip()]
    for dataset in ('sharegpt','humaneval','gsm8k'):
        selected=[r for r in original if r['dataset']==dataset]
        path=root/'manifests'/f'{model}_{dataset}_20_max128.jsonl'
        new=[json.loads(s) for s in path.read_text().split('\n') if s.strip()]
        assert len(new)==len(selected)==20
        for before,after in zip(selected,new):
            expected=dict(before,max_output_tokens=128,context_contract=dict(before['context_contract'],output_tokens_reserved=128))
            assert after==expected
            assert after['context_contract']['prompt_tokens']+128+8<=4096
        prompt_sets[model,dataset]=[(r['request_id'],r['source_id'],r['prompt']) for r in new]
        manifest_checks+=1
for dataset in ('sharegpt','humaneval','gsm8k'):
    assert prompt_sets['qwen',dataset]==prompt_sets['glm',dataset]
print(json.dumps({'status':'passed','randomized_row_plan_cases':plans,'capture_histogram_cases':18,
                  'manifest_cases':manifest_checks,'selected_prompt_records':120,
                  'accelerator_initialized':False},indent=2))
