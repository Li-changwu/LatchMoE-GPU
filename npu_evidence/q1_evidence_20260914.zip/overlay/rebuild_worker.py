"""Named worker RPC for experiment evidence; no callable serialization required."""
class EvidenceWorkerExtension:
    def get_rebuild_evidence(self, reset=False):
        import hashlib
        import torch
        import vllm
        import vllm_ascend
        import vllm_moe_offload_ascend as package
        from vllm_moe_offload_ascend.moe_offload.runtime import get_moe_offload_runtime
        runtime = get_moe_offload_runtime()
        torch.npu.synchronize()
        if reset:
            torch.npu.reset_peak_memory_stats()
            runtime._rebuild_audit = {"stages":0,"hits":0,"misses":0,"h2d_bytes":0,
                                      "waves":0,"digest":hashlib.sha256()}
        audit = dict(getattr(runtime, "_rebuild_audit", {}))
        if "digest" in audit: audit["digest"] = audit["digest"].hexdigest()
        return {"allocated_bytes":torch.npu.memory_allocated(),
                "reserved_bytes":torch.npu.memory_reserved(),
                "peak_allocated_bytes":torch.npu.max_memory_allocated(),
                "peak_reserved_bytes":torch.npu.max_memory_reserved(),
                "managed_memory_ledger":runtime.memory_ledger().to_jsonable(),
                "audit":audit,"package_file":package.__file__,
                "vllm_file":vllm.__file__,"vllm_version":str(vllm.__version__),
                "vllm_ascend_file":vllm_ascend.__file__,"torch_version":str(torch.__version__)}
