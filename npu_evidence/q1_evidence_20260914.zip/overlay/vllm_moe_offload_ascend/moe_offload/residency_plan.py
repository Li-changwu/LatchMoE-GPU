from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import asdict, dataclass, replace
from typing import Any, Mapping, Sequence

_BYTES_PER_GIB = 1 << 30
_PLANNER_VERSION = "gib-layer-selection-v1"

_MODEL_TYPE_KEYS = ("model_type", "architectures")
_EXPERT_COUNT_KEYS = ("num_experts", "n_routed_experts", "moe_num_experts")
_INTERMEDIATE_KEYS = ("moe_intermediate_size", "intermediate_size")


@dataclass(frozen=True)
class LayerExpertBytes:
    layer_id: int
    routed_expert_bytes: int

    def __post_init__(self) -> None:
        if int(self.layer_id) < 0:
            raise ValueError("layer_id must be non-negative")
        if int(self.routed_expert_bytes) <= 0:
            raise ValueError("routed_expert_bytes must be positive")

    def to_jsonable(self) -> dict[str, int]:
        return {
            "layer_id": int(self.layer_id),
            "routed_expert_bytes": int(self.routed_expert_bytes),
        }

    @classmethod
    def from_jsonable(cls, value: Mapping[str, Any]) -> "LayerExpertBytes":
        return cls(
            layer_id=int(value["layer_id"]),
            routed_expert_bytes=int(value["routed_expert_bytes"]),
        )


@dataclass(frozen=True)
class MoeResidencyPlan:
    planner_version: str
    plan_id: str
    model_fingerprint: dict[str, Any]
    requested_offload_bytes: int
    effective_offloaded_bytes: int
    eligible_layer_ids: tuple[int, ...]
    offloaded_layer_ids: tuple[int, ...]
    resident_layer_ids: tuple[int, ...]
    layer_expert_bytes: tuple[LayerExpertBytes, ...]
    configured_num_slots: int | None
    recommended_num_slots: int
    effective_num_slots: int
    requested_offload_gib: float
    effective_offloaded_weight_gib: float
    main_slot_cache_gib: float
    net_hbm_saved_gib: float
    ledger: dict[str, Any]

    @property
    def offloaded_layer_count(self) -> int:
        return len(self.offloaded_layer_ids)

    def to_jsonable(self) -> dict[str, Any]:
        return {
            "planner_version": self.planner_version,
            "plan_id": self.plan_id,
            "model_fingerprint": _jsonable(self.model_fingerprint),
            "requested_offload_bytes": int(self.requested_offload_bytes),
            "effective_offloaded_bytes": int(self.effective_offloaded_bytes),
            "eligible_layer_ids": list(self.eligible_layer_ids),
            "offloaded_layer_ids": list(self.offloaded_layer_ids),
            "resident_layer_ids": list(self.resident_layer_ids),
            "layer_expert_bytes": [
                item.to_jsonable() for item in self.layer_expert_bytes
            ],
            "configured_num_slots": self.configured_num_slots,
            "recommended_num_slots": int(self.recommended_num_slots),
            "effective_num_slots": int(self.effective_num_slots),
            "requested_offload_gib": float(self.requested_offload_gib),
            "effective_offloaded_weight_gib": float(
                self.effective_offloaded_weight_gib
            ),
            "main_slot_cache_gib": float(self.main_slot_cache_gib),
            "net_hbm_saved_gib": float(self.net_hbm_saved_gib),
            "ledger": _jsonable(self.ledger),
        }


def _jsonable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def _canonical_json(value: Any) -> str:
    return json.dumps(
        _jsonable(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )


def _dtype_size_bytes(dtype: Any) -> int:
    text = str(dtype or "bfloat16").lower().replace("torch.", "")
    if text in {"float32", "fp32"}:
        return 4
    if text in {"float16", "fp16", "bfloat16", "bf16"}:
        return 2
    if text in {"float8", "fp8", "int8", "uint8"}:
        return 1
    if text in {"int4", "uint4", "fp4"}:
        return 1
    raise ValueError(f"unsupported expert dtype {dtype!r}")


def _first_int(config: Mapping[str, Any], keys: Sequence[str], label: str) -> int:
    for key in keys:
        value = config.get(key)
        if value is not None:
            try:
                value = int(value)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{label} must be an integer, got {value!r}") from exc
            if value <= 0:
                raise ValueError(f"{label} must be positive, got {value}")
            return value
    raise ValueError(f"missing {label} in model config")


def _model_type(config: Mapping[str, Any]) -> str:
    value = config.get("model_type")
    if value is not None:
        return str(value).lower()
    architectures = config.get("architectures")
    if isinstance(architectures, Sequence) and not isinstance(
        architectures, (str, bytes)
    ):
        if architectures:
            return str(architectures[0]).lower()
    return ""


def _discover_eligible_layer_ids(
    config: Mapping[str, Any],
    *,
    layer_metadata: Sequence[LayerExpertBytes] | None,
) -> tuple[int, ...]:
    if layer_metadata is not None:
        ids = tuple(int(item.layer_id) for item in layer_metadata)
        if not ids:
            raise ValueError("eligible routed MoE layers cannot be empty")
        if len(set(ids)) != len(ids):
            raise ValueError("eligible routed MoE layer IDs must be unique")
        return ids

    explicit = config.get("moe_layer_ids")
    if explicit is not None:
        try:
            ids = tuple(int(item) for item in explicit)
        except (TypeError, ValueError) as exc:
            raise ValueError("moe_layer_ids must be an integer sequence") from exc
        if not ids or len(set(ids)) != len(ids):
            raise ValueError("eligible routed MoE layers must be non-empty/unique")
        return ids

    num_layers = _first_int(config, ("num_hidden_layers", "num_layers"), "layer count")
    dense_ids = {
        int(item)
        for item in config.get("dense_layer_ids", ())
    }
    model_type = _model_type(config)
    if model_type in {"qwen3_moe", "qwen3_next", "qwen3_next_moe"}:
        ids = tuple(i for i in range(num_layers) if i not in dense_ids)
    elif model_type in {"glm4_moe_lite", "glm4_moe", "glm_4_moe_lite"}:
        # GLM-4.7-Flash has a dense layer 0 in the checked checkpoint.
        ids = tuple(i for i in range(num_layers) if i not in dense_ids and i != 0)
    elif (
        config.get("hidden_size") is not None
        and any(config.get(key) is not None for key in _EXPERT_COUNT_KEYS)
        and any(config.get(key) is not None for key in _INTERMEDIATE_KEYS)
    ):
        # Test fixtures and older checkpoint metadata may omit model_type while
        # still exposing enough routed-MoE metadata to identify every layer.
        ids = tuple(i for i in range(num_layers) if i not in dense_ids)
    else:
        raise ValueError(
            "cannot identify eligible routed MoE layers for model type "
            f"{model_type or '<missing>'}; provide moe_layer_ids or a supported "
            "MoE architecture"
        )
    if not ids:
        raise ValueError("eligible routed MoE layers cannot be empty")
    return ids


def _uniform_layer_bytes(config: Mapping[str, Any]) -> int:
    hidden_size = _first_int(config, ("hidden_size",), "hidden_size")
    intermediate_size = _first_int(
        config,
        _INTERMEDIATE_KEYS,
        "MoE intermediate size",
    )
    expert_count = _first_int(config, _EXPERT_COUNT_KEYS, "routed expert count")
    dtype_bytes = _dtype_size_bytes(config.get("torch_dtype", "bfloat16"))
    return int(3 * hidden_size * intermediate_size * expert_count * dtype_bytes)


def _normalise_layer_metadata(
    metadata: Sequence[LayerExpertBytes],
    eligible_ids: tuple[int, ...],
) -> tuple[LayerExpertBytes, ...]:
    by_id = {int(item.layer_id): item for item in metadata}
    if set(by_id) != set(eligible_ids):
        raise ValueError(
            "measured layer metadata must cover exactly the eligible routed MoE layers"
        )
    return tuple(by_id[layer_id] for layer_id in eligible_ids)


def _select_uniform_ids(
    eligible_ids: tuple[int, ...],
    count: int,
) -> tuple[int, ...]:
    if count <= 0:
        return ()
    if count >= len(eligible_ids):
        return eligible_ids
    selected_indices: list[int] = []
    used: set[int] = set()
    for j in range(count):
        index = min(math.floor((j + 0.5) * len(eligible_ids) / count), len(eligible_ids) - 1)
        if index in used:
            for distance in range(1, len(eligible_ids)):
                candidates = (index - distance, index + distance)
                replacement = next(
                    (candidate for candidate in candidates if 0 <= candidate < len(eligible_ids) and candidate not in used),
                    None,
                )
                if replacement is not None:
                    index = replacement
                    break
        used.add(index)
        selected_indices.append(index)
    return tuple(eligible_ids[index] for index in sorted(selected_indices))


def _select_heterogeneous_ids(
    layer_bytes: tuple[LayerExpertBytes, ...],
    requested_bytes: int,
) -> tuple[int, ...]:
    selected: list[int] = []
    total = 0
    for item in layer_bytes:
        if total >= requested_bytes:
            break
        selected.append(item.layer_id)
        total += item.routed_expert_bytes
    return tuple(selected)


def _fingerprint(
    config: Mapping[str, Any],
    eligible_ids: tuple[int, ...],
    layer_bytes: tuple[LayerExpertBytes, ...],
) -> dict[str, Any]:
    values: dict[str, Any] = {
        "model_type": _model_type(config),
        "num_hidden_layers": config.get("num_hidden_layers", config.get("num_layers")),
        "hidden_size": config.get("hidden_size"),
        "moe_intermediate_size": config.get(
            "moe_intermediate_size",
            config.get("intermediate_size"),
        ),
        "num_experts": config.get(
            "num_experts",
            config.get("n_routed_experts", config.get("moe_num_experts")),
        ),
        "num_experts_per_tok": config.get(
            "num_experts_per_tok",
            config.get("num_experts_per_token", config.get("moe_top_k")),
        ),
        "torch_dtype": str(config.get("torch_dtype", "bfloat16")),
        "eligible_layer_ids": list(eligible_ids),
        "layer_expert_bytes": [item.to_jsonable() for item in layer_bytes],
    }
    return _jsonable(values)


def _plan_id(payload: Mapping[str, Any]) -> str:
    unsigned = dict(payload)
    unsigned.pop("plan_id", None)
    return hashlib.sha256(_canonical_json(unsigned).encode("utf-8")).hexdigest()


def build_residency_plan(
    requested_offload_gib: float,
    model_config: Mapping[str, Any],
    *,
    engine_args: Any | None = None,
    layer_metadata: Sequence[LayerExpertBytes] | None = None,
    profile_path: str | None = None,
) -> MoeResidencyPlan:
    del profile_path  # Profile-guided swaps are added after the pure planner gate.
    try:
        requested_gib = float(requested_offload_gib)
    except (TypeError, ValueError) as exc:
        raise ValueError("requested_offload_gib must be numeric") from exc
    if requested_gib < 0:
        raise ValueError("requested_offload_gib must be non-negative")
    requested_bytes = int(math.ceil(requested_gib * _BYTES_PER_GIB))
    eligible_ids = _discover_eligible_layer_ids(
        model_config,
        layer_metadata=layer_metadata,
    )
    if layer_metadata is None:
        per_layer = _uniform_layer_bytes(model_config)
        layer_bytes = tuple(
            LayerExpertBytes(layer_id, per_layer) for layer_id in eligible_ids
        )
        accounting_source = "config_formula"
        selection_mode = "uniform"
    else:
        layer_bytes = _normalise_layer_metadata(layer_metadata, eligible_ids)
        accounting_source = "measured_parameter_shapes"
        selection_mode = "ordered_prefix"

    if requested_bytes == 0:
        selected_ids = ()
    elif selection_mode == "uniform":
        per_layer = layer_bytes[0].routed_expert_bytes
        count = min(
            len(eligible_ids),
            max(1, math.ceil(requested_bytes / per_layer)),
        )
        selected_ids = _select_uniform_ids(eligible_ids, count)
    else:
        selected_ids = _select_heterogeneous_ids(layer_bytes, requested_bytes)

    selected_set = set(selected_ids)
    effective_bytes = sum(
        item.routed_expert_bytes
        for item in layer_bytes
        if item.layer_id in selected_set
    )
    resident_ids = tuple(item for item in eligible_ids if item not in selected_set)

    configured_slots: int | None = None
    raw_slots = os.getenv("VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS")
    if raw_slots and os.getenv("VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS_AUTOCONFIG_BOOTSTRAP") != "1":
        try:
            configured_slots = int(raw_slots)
        except ValueError as exc:
            raise ValueError("VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS must be an integer") from exc
        if configured_slots <= 0:
            raise ValueError("VLLM_ASCEND_MOE_OFFLOAD_NUM_SLOTS must be positive")
    if engine_args is not None:
        value = getattr(engine_args, "num_slots", None)
        if value is not None and int(value) > 0:
            configured_slots = int(value)

    fingerprint = _fingerprint(model_config, eligible_ids, layer_bytes)
    ledger: dict[str, Any] = {
        "requested_offload_bytes": requested_bytes,
        "requested_offload_gib": requested_gib,
        "effective_offloaded_bytes": effective_bytes,
        "effective_offloaded_weight_gib": effective_bytes / _BYTES_PER_GIB,
        "resident_routed_expert_bytes": sum(
            item.routed_expert_bytes for item in layer_bytes if item.layer_id in set(resident_ids)
        ),
        "resident_routed_expert_gib": sum(
            item.routed_expert_bytes for item in layer_bytes if item.layer_id in set(resident_ids)
        ) / _BYTES_PER_GIB,
        "host_expert_store_bytes": effective_bytes,
        "host_expert_store_gib": effective_bytes / _BYTES_PER_GIB,
        "main_slot_cache_bytes": 0,
        "main_slot_cache_gib": 0.0,
        "net_hbm_saved_bytes": effective_bytes,
        "net_hbm_saved_gib": effective_bytes / _BYTES_PER_GIB,
        "configured_num_slots": configured_slots,
        "recommended_num_slots": 0,
        "effective_num_slots": configured_slots or 0,
        "eligible_layer_count": len(eligible_ids),
        "offloaded_layer_count": len(selected_ids),
        "capped_to_eligible_layers": len(selected_ids) == len(eligible_ids) and requested_bytes > effective_bytes,
        "byte_accounting_source": accounting_source,
        "selection_mode": selection_mode,
        "memory_values_are_measured": False,
    }
    payload: dict[str, Any] = {
        "planner_version": _PLANNER_VERSION,
        "model_fingerprint": fingerprint,
        "requested_offload_bytes": requested_bytes,
        "effective_offloaded_bytes": effective_bytes,
        "eligible_layer_ids": list(eligible_ids),
        "offloaded_layer_ids": list(selected_ids),
        "resident_layer_ids": list(resident_ids),
        "layer_expert_bytes": [item.to_jsonable() for item in layer_bytes],
        "configured_num_slots": configured_slots,
        "recommended_num_slots": 0,
        "effective_num_slots": configured_slots or 0,
        "requested_offload_gib": requested_gib,
        "effective_offloaded_weight_gib": effective_bytes / _BYTES_PER_GIB,
        "main_slot_cache_gib": 0.0,
        "net_hbm_saved_gib": effective_bytes / _BYTES_PER_GIB,
        "ledger": ledger,
    }
    plan_id = _plan_id(payload)
    return MoeResidencyPlan(
        planner_version=_PLANNER_VERSION,
        plan_id=plan_id,
        model_fingerprint=fingerprint,
        requested_offload_bytes=requested_bytes,
        effective_offloaded_bytes=effective_bytes,
        eligible_layer_ids=eligible_ids,
        offloaded_layer_ids=selected_ids,
        resident_layer_ids=resident_ids,
        layer_expert_bytes=layer_bytes,
        configured_num_slots=configured_slots,
        recommended_num_slots=0,
        effective_num_slots=configured_slots or 0,
        requested_offload_gib=requested_gib,
        effective_offloaded_weight_gib=effective_bytes / _BYTES_PER_GIB,
        main_slot_cache_gib=0.0,
        net_hbm_saved_gib=effective_bytes / _BYTES_PER_GIB,
        ledger=ledger,
    )


def repartition_residency_plan(
    plan: MoeResidencyPlan,
    *,
    offloaded_layer_ids: Sequence[int],
    resident_layer_ids: Sequence[int],
) -> MoeResidencyPlan:
    """Rebuild the authoritative plan after a profile-guided layer swap.

    Profile guidance changes which eligible layers are resident, but it must
    also update the serialized plan consumed by workers.  Keep the original
    layer order and recompute all byte-derived accounting and the plan ID.
    """

    eligible = tuple(int(layer_id) for layer_id in plan.eligible_layer_ids)
    eligible_set = set(eligible)
    offloaded_set = {int(layer_id) for layer_id in offloaded_layer_ids}
    resident_set = {int(layer_id) for layer_id in resident_layer_ids}
    if offloaded_set & resident_set:
        raise ValueError("profile-guided residency sets must be disjoint")
    if offloaded_set | resident_set != eligible_set:
        raise ValueError(
            "profile-guided residency sets must partition eligible layers"
        )

    ordered_offloaded = tuple(layer_id for layer_id in eligible if layer_id in offloaded_set)
    ordered_resident = tuple(layer_id for layer_id in eligible if layer_id in resident_set)
    bytes_by_layer = {
        int(item.layer_id): int(item.routed_expert_bytes)
        for item in plan.layer_expert_bytes
    }
    effective_bytes = sum(bytes_by_layer[layer_id] for layer_id in ordered_offloaded)
    resident_bytes = sum(bytes_by_layer[layer_id] for layer_id in ordered_resident)
    effective_gib = effective_bytes / _BYTES_PER_GIB
    net_saved_gib = max(0.0, effective_gib - float(plan.main_slot_cache_gib))
    ledger = dict(plan.ledger)
    ledger.update(
        {
            "effective_offloaded_bytes": effective_bytes,
            "effective_offloaded_weight_gib": effective_gib,
            "resident_routed_expert_bytes": resident_bytes,
            "resident_routed_expert_gib": resident_bytes / _BYTES_PER_GIB,
            "host_expert_store_bytes": effective_bytes,
            "host_expert_store_gib": effective_gib,
            "net_hbm_saved_bytes": int(round(net_saved_gib * _BYTES_PER_GIB)),
            "net_hbm_saved_gib": net_saved_gib,
            "offloaded_layer_count": len(ordered_offloaded),
        }
    )
    payload = plan.to_jsonable()
    payload.update(
        {
            "effective_offloaded_bytes": effective_bytes,
            "offloaded_layer_ids": list(ordered_offloaded),
            "resident_layer_ids": list(ordered_resident),
            "effective_offloaded_weight_gib": effective_gib,
            "net_hbm_saved_gib": net_saved_gib,
            "ledger": ledger,
        }
    )
    return replace(
        plan,
        plan_id=_plan_id(payload),
        effective_offloaded_bytes=effective_bytes,
        offloaded_layer_ids=ordered_offloaded,
        resident_layer_ids=ordered_resident,
        effective_offloaded_weight_gib=effective_gib,
        net_hbm_saved_gib=net_saved_gib,
        ledger=ledger,
    )


def finalize_residency_plan_slot_accounting(
    plan: MoeResidencyPlan,
    *,
    configured_num_slots: int | None,
    recommended_num_slots: int,
    effective_num_slots: int,
    main_slot_cache_gib: float,
) -> MoeResidencyPlan:
    """Attach authoritative slot/cache accounting after capacity resolution."""

    configured = (
        None if configured_num_slots is None else int(configured_num_slots)
    )
    recommended = int(recommended_num_slots)
    effective = int(effective_num_slots)
    if recommended < 0 or effective < 0:
        raise ValueError("slot counts must be non-negative")
    if configured is not None and configured < 0:
        raise ValueError("configured_num_slots must be non-negative")
    cache_gib = float(main_slot_cache_gib)
    if cache_gib < 0:
        raise ValueError("main_slot_cache_gib must be non-negative")
    effective_gib = float(plan.effective_offloaded_weight_gib)
    net_saved_gib = max(0.0, effective_gib - cache_gib)
    ledger = dict(plan.ledger)
    ledger.update(
        {
            "configured_num_slots": configured,
            "recommended_num_slots": recommended,
            "effective_num_slots": effective,
            "main_slot_cache_gib": cache_gib,
            "main_slot_cache_bytes": int(round(cache_gib * _BYTES_PER_GIB)),
            "net_hbm_saved_gib": net_saved_gib,
            "net_hbm_saved_bytes": int(round(net_saved_gib * _BYTES_PER_GIB)),
            "memory_values_are_measured": False,
        }
    )
    payload = plan.to_jsonable()
    payload.update(
        {
            "configured_num_slots": configured,
            "recommended_num_slots": recommended,
            "effective_num_slots": effective,
            "main_slot_cache_gib": cache_gib,
            "net_hbm_saved_gib": net_saved_gib,
            "ledger": ledger,
        }
    )
    plan_id = _plan_id(payload)
    return replace(
        plan,
        plan_id=plan_id,
        configured_num_slots=configured,
        recommended_num_slots=recommended,
        effective_num_slots=effective,
        main_slot_cache_gib=cache_gib,
        net_hbm_saved_gib=net_saved_gib,
        ledger=ledger,
    )


def serialize_residency_plan(plan: MoeResidencyPlan) -> str:
    payload = plan.to_jsonable()
    expected = _plan_id(payload)
    if expected != plan.plan_id:
        raise ValueError(
            f"residency plan ID mismatch: expected {expected}, got {plan.plan_id}"
        )
    return _canonical_json(payload)


def deserialize_residency_plan(raw: str) -> MoeResidencyPlan:
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid serialized residency plan JSON") from exc
    if not isinstance(value, Mapping):
        raise ValueError("serialized residency plan must be an object")
    required = {
        "planner_version", "plan_id", "model_fingerprint",
        "requested_offload_bytes", "effective_offloaded_bytes",
        "eligible_layer_ids", "offloaded_layer_ids", "resident_layer_ids",
        "layer_expert_bytes", "configured_num_slots",
        "recommended_num_slots", "effective_num_slots",
        "requested_offload_gib", "effective_offloaded_weight_gib",
        "main_slot_cache_gib", "net_hbm_saved_gib", "ledger",
    }
    missing = sorted(required - set(value))
    if missing:
        raise ValueError(f"serialized residency plan missing fields: {', '.join(missing)}")
    eligible = tuple(int(item) for item in value["eligible_layer_ids"])
    offloaded = tuple(int(item) for item in value["offloaded_layer_ids"])
    resident = tuple(int(item) for item in value["resident_layer_ids"])
    if len(set(eligible)) != len(eligible):
        raise ValueError("serialized eligible layer IDs must be unique")
    if set(offloaded) & set(resident) or set(offloaded) | set(resident) != set(eligible):
        raise ValueError("serialized resident/offloaded IDs do not partition eligible IDs")
    layer_bytes = tuple(
        LayerExpertBytes.from_jsonable(item) for item in value["layer_expert_bytes"]
    )
    if tuple(item.layer_id for item in layer_bytes) != eligible:
        raise ValueError("serialized layer byte metadata does not match eligible IDs")
    plan = MoeResidencyPlan(
        planner_version=str(value["planner_version"]),
        plan_id=str(value["plan_id"]),
        model_fingerprint=dict(value["model_fingerprint"]),
        requested_offload_bytes=int(value["requested_offload_bytes"]),
        effective_offloaded_bytes=int(value["effective_offloaded_bytes"]),
        eligible_layer_ids=eligible,
        offloaded_layer_ids=offloaded,
        resident_layer_ids=resident,
        layer_expert_bytes=layer_bytes,
        configured_num_slots=(
            None
            if value["configured_num_slots"] is None
            else int(value["configured_num_slots"])
        ),
        recommended_num_slots=int(value["recommended_num_slots"]),
        effective_num_slots=int(value["effective_num_slots"]),
        requested_offload_gib=float(value["requested_offload_gib"]),
        effective_offloaded_weight_gib=float(value["effective_offloaded_weight_gib"]),
        main_slot_cache_gib=float(value["main_slot_cache_gib"]),
        net_hbm_saved_gib=float(value["net_hbm_saved_gib"]),
        ledger=dict(value["ledger"]),
    )
    if _plan_id(plan.to_jsonable()) != plan.plan_id:
        raise ValueError("serialized residency plan has an invalid plan_id")
    if any(
        item.routed_expert_bytes <= 0
        for item in plan.layer_expert_bytes
    ):
        raise ValueError("serialized layer byte values must be positive")
    if plan.requested_offload_bytes < 0 or plan.effective_offloaded_bytes < 0:
        raise ValueError("serialized plan byte values must be non-negative")
    return plan


def validate_plan_against_model(
    plan: MoeResidencyPlan,
    model_config: Mapping[str, Any],
) -> None:
    expected_ids = _discover_eligible_layer_ids(model_config, layer_metadata=None)
    expected_layers = tuple(
        LayerExpertBytes(item, _uniform_layer_bytes(model_config))
        for item in expected_ids
    )
    expected_fingerprint = _fingerprint(model_config, expected_ids, expected_layers)
    if plan.model_fingerprint != expected_fingerprint:
        raise ValueError(
            "residency plan model fingerprint mismatch: "
            f"plan={plan.model_fingerprint!r}, expected={expected_fingerprint!r}"
        )
