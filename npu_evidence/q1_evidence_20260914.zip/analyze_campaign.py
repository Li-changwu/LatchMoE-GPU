"""Read-only evidence validation and Q1 report; no NPU imports or launches."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics

MODELS=('qwen','glm')
DATASETS=('sharegpt','humaneval','gsm8k')
ARMS=('latchmoe','eager','native')

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def records(p):
    with p.open(encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def analyze(root):
    selected=read(root/'selected_runs.json') if (root/'selected_runs.json').exists() else {}
    result={'complete':False,'valid':False,'units':[],'errors':[],
            'missing':[],'comparisons':[],'pending_quality_checks':[],
            'scope':'one selected complete run per configuration; predeclared stability repeat disclosed separately'}
    outputs={}
    for model in MODELS:
        for dataset in DATASETS:
            manifest=root/'manifests'/f'{model}_{dataset}_20_max128.jsonl'
            ids=[r['request_id'] for r in records(manifest)]
            assert len(ids)==len(set(ids))==20
            for arm in ARMS:
                name=f'{model}_{dataset}_{arm}_r1'
                name=selected.get(name,name)
                d=root/'runs'/name
                if not (d/'unit.json').exists() or read(d/'unit.json')['status']=='running':
                    result['missing'].append(name)
                    continue
                try:
                    u=read(d/'unit.json')
                    assert u['status']=='complete' and u['exit_code']==0, 'process failed'
                    s=read(d/'summary.json')
                    w=read(d/'worker_after.json')[0]
                    assert s['status']=='ok' and s['completed']==20, 'incomplete requests'
                    assert not u['verify'], 'reference validation enabled during timing'
                    assert u['manifest_sha256']==digest(manifest), 'manifest changed'
                    assert s['requested_request_ids']==ids, 'request selection/order changed'
                    assert s['ignore_eos'] is False and s['disable_thinking'], 'generation contract changed'
                    assert s['tensor_parallel_size']==1 and s['request_batch_size']==1
                    assert s['npu_profiler_dir'] is None, 'profiler enabled during timing'
                    host=u.get('execution_host','vllm-hust-lcw-23rc')
                    expected_device=6 if model=='qwen' else (7 if host=='lcw-91' else 5)
                    assert u['device']==expected_device, 'device changed'
                    assert u['numa_node']==(4 if model=='qwen' else 2), 'NUMA changed'
                    assert w['vllm_file'].startswith('/workspace/latchmoe-locked-stack/vllm-hust/'), 'wrong vLLM'
                    assert w['vllm_ascend_file'].startswith('/workspace/latchmoe-locked-stack/vllm-ascend-hust/'), 'wrong Ascend runtime'
                    assert w['wave_reuse']['decode_addresses_unchanged'], 'weight/mapping address changed'
                    recorded_root=u.get('manifest',str(manifest)).replace('\\','/').rsplit('/',2)[0]
                    assert w['package_file'].startswith(recorded_root+'/overlay/'), 'wrong offload overlay'
                    for rel in ('runner.py','wave_worker.py','wave_executor.py'):
                        assert u['source_hashes'][rel]==digest(root/rel), f'source changed: {rel}'
                    for rel,h in u['source_hashes'].items():
                        if rel.startswith('overlay/'):
                            assert digest(root/rel)==h, f'overlay changed: {rel}'
                    a=w['wave_reuse']['arena']
                    if arm!='native':
                        assert s['async_load'], 'async load disabled'
                        assert a and a['calls']>0 and a['fallbacks']==0, 'custom path missing/fallback'
                        assert a['verified']==0, 'verification included in timing'
                        assert a['graphs']>0 and a['replays']>0 if arm=='latchmoe' else a['graphs']==a['replays']==0
                        assert s['execution_mode']==('graph' if arm=='latchmoe' else 'eager')
                        decode_replays=w['audit'].get('expert_replay_pieces',0)
                        assert decode_replays>0 if arm=='latchmoe' else decode_replays==0, 'Decode graph mode mismatch'
                        ledger=w['managed_memory_ledger']
                        assert ledger['registered_layers']==12 and not ledger['original_expert_weights_retained']
                        assert ledger['slot_bank_bytes']==(3623878656 if model=='qwen' else 1132462080), 'expert slot budget mismatch'
                    else:
                        assert s['native_offload_enabled'] and s['execution_mode']=='graph'
                        assert 'Replaying aclgraph' in (d/'runner.log').read_text(errors='replace'), 'native graph replay not observed'
                        config=s['qualification_diagnostics']['compilation_config_override']
                        assert {'vllm::wait_prefetch','vllm::start_prefetch'}<=set(config['splitting_ops']), 'native prefetch seams absent'
                    out=records(d/'outputs.jsonl')
                    per=s['per_request']
                    assert [r['request_id'] for r in out]==ids, 'output ids/order changed'
                    assert [r['request_id'] for r in per]==ids, 'metric ids/order changed'
                    for o,p in zip(out,per):
                        assert 1<=len(o['output_token_ids'])==p['output_tokens']<=128
                        for key in ('ttft_ms','request_stream_ms','request_call_ms'):
                            assert math.isfinite(p[key]) and p[key]>0, f'invalid {key}'
                        if p['output_tokens']>1:
                            assert math.isfinite(p['tpot_ms']) and p['tpot_ms']>0
                            expected=p['ttft_ms']+(p['output_tokens']-1)*p['tpot_ms']
                            assert abs(expected-p['request_stream_ms'])<1e-6
                        else:
                            assert p['tpot_ms'] is None
                    outputs[model,dataset,arm]=out
                    row={'name':name,'model':model,'dataset':dataset,'arm':arm,'execution_host':host,
                         'device':u['device'],'numa_node':u['numa_node'],
                         'completed':s['completed'],'total_output_tokens':s['total_output_tokens'],
                         'duration_s':s['duration_s'],'output_throughput_tok_s':s['output_throughput_tok_s'],
                         'start_unix':u['start_unix'],'finish_unix':u['finish_unix'],
                         'audit':w['audit'],'managed_memory_ledger':w['managed_memory_ledger'],
                         'arena':a}
                    for key in ('ttft_ms','tpot_ms','request_stream_ms','request_call_ms'):
                        values=[r[key] for r in per if r[key] is not None]
                        row[key+'_p50']=statistics.median(values) if values else None
                        row[key+'_mean']=statistics.mean(values) if values else None
                    for key in ('allocated_bytes','reserved_bytes','peak_allocated_bytes','peak_reserved_bytes'):
                        row[key.replace('_bytes','_gib')]=w[key]/2**30
                    result['units'].append(row)
                except (AssertionError,KeyError,TypeError,ValueError,OSError) as e:
                    result['errors'].append({'unit':name,'error':str(e)})
    for model in MODELS:
        for dataset in DATASETS:
            environments={(r['execution_host'],r['device'],r['numa_node']) for r in result['units']
                          if r['model']==model and r['dataset']==dataset}
            if len(environments)>1:
                result['errors'].append({'model':model,'dataset':dataset,'error':'comparison spans different environments'})
            ref=outputs.get((model,dataset,'latchmoe'))
            if ref is None: continue
            for arm in ('eager','native'):
                candidate=outputs.get((model,dataset,arm))
                if candidate is None: continue
                mismatch=[]
                for r,c in zip(ref,candidate):
                    x,y=r['output_token_ids'],c['output_token_ids']
                    if x!=y:
                        first=next((i for i,(a,b) in enumerate(zip(x,y)) if a!=b),min(len(x),len(y)))
                        mismatch.append({'request_id':r['request_id'],'first_mismatch_position':first,
                                         'latchmoe_length':len(x),'comparison_length':len(y)})
                entry={'model':model,'dataset':dataset,'comparison':arm,'compared_requests':len(ref),
                       'exact_match_requests':len(ref)-len(mismatch),'mismatches':mismatch}
                if arm=='eager':
                    pair={r['arm']:r for r in result['units'] if r['model']==model and r['dataset']==dataset}
                    ga,ea=pair['latchmoe']['audit'],pair['eager']['audit']
                    entry['cache_audit']={'same_history_digest':ga.get('digest')==ea.get('digest'),
                        'latchmoe_misses':ga.get('misses'),'eager_misses':ea.get('misses'),
                        'latchmoe_h2d_bytes':ga.get('h2d_bytes'),'eager_h2d_bytes':ea.get('h2d_bytes'),
                        'same_wave_count':ga.get('waves')==ea.get('waves')}
                result['comparisons'].append(entry)
                if mismatch: result['errors'].append({'comparison':entry,'error':'output token mismatch'})
    if (root/'stability_plan.json').exists():
        plan=read(root/'stability_plan.json')
        if selected.get(plan['canonical'])!=plan['required_primary']:
            result['pending_quality_checks'].append('Predeclared complete stability repeat is not selected')
        if not (root/'stability_analysis.json').exists():
            result['pending_quality_checks'].append('Stability repeat audit is not complete')
        else:
            stability=read(root/'stability_analysis.json')
            if not (stability['names'][1]==plan['required_primary'] and stability['matched_requests']==20
                    and stability['same_core_command_environment'] and stability['repeat_within_15pct_tpot_band']
                    and stability['repeat_median_within_5pct_initial']):
                result['errors'].append({'error':'Required stability repeat did not pass its predeclared checks'})
            result['stability_audit']=stability
    result['complete']=not result['missing'] and len(result['units'])==18
    result['valid']=result['complete'] and not result['errors'] and len(result['comparisons'])==12 and not result['pending_quality_checks']
    return result

def write(root,result):
    (root/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    rows=result['units']
    if rows:
        fields=[k for k in rows[0] if k not in ('audit','managed_memory_ledger','arena')]
        with (root/'results.csv').open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
            writer.writeheader();writer.writerows(rows)
    lines=['# Q1 重跑结果', '',
           f"已通过基础证据检查：{len(rows)}/18 组；输出对比完成：{len(result['comparisons'])}/12 项。",
           f"完整结果可用：{'是' if result['valid'] else '否，尚有未完成或未通过项目'}。",'',
           '各数据集使用原固定 20 条 Prompt，输出上限 128、允许 EOS；主矩阵每配置选用一组完整运行。GLM HumanEval Native 的预定完整复测另行披露，见 STABILITY.zh.md；不构造跨启动置信区间。',
           '下表 TPOT 为逐请求 TPOT 的中位数；完整延迟为逐请求调用实测墙钟时间的中位数，包含 Prefill 和 Decode。','',
           '| 模型 | 数据集 | 方法 | 服务器 | TTFT中位数(ms) | TPOT中位数(ms) | 完整延迟中位数(s) | 输出token总数 | 峰值allocated(GiB) |',
           '|---|---|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        tpot=f"{r['tpot_ms_p50']:.2f}" if r['tpot_ms_p50'] is not None else '未定义'
        lines.append(f"| {r['model']} | {r['dataset']} | {r['arm']} | {r['execution_host']} | {r['ttft_ms_p50']:.2f} | {tpot} | {r['request_call_ms_p50']/1000:.3f} | {r['total_output_tokens']} | {r['peak_allocated_gib']:.3f} |")
    by_name={(r['model'],r['dataset'],r['arm']):r for r in rows}
    lines+=['','各项速度比 = 对照方法的中位数 / LatchMoE 的中位数，大于 1 表示 LatchMoE 更快。仅输出 token 完全一致的成对结果列入下表。','',
            '| 模型 | 数据集 | 对照 | TTFT速度比 | TPOT速度比 | 完整延迟速度比 |',
            '|---|---|---|---:|---:|---:|']
    for c in result['comparisons']:
        if c['mismatches']: continue
        a=by_name[c['model'],c['dataset'],'latchmoe']
        b=by_name[c['model'],c['dataset'],c['comparison']]
        ratios=[b[k]/a[k] if a[k] and b[k] else float('nan') for k in ('ttft_ms_p50','tpot_ms_p50','request_call_ms_p50')]
        lines.append(f"| {c['model']} | {c['dataset']} | {c['comparison']} | {ratios[0]:.3f}× | {ratios[1]:.3f}× | {ratios[2]:.3f}× |")
    lines+=['','ShareGPT 保留原服务器的完整结果；HumanEval 与 GSM8K 在容器迁移后的 lcw-91 上完整补跑。两台服务器均为 910B2，但不把本矩阵描述为同一台物理服务器的结果。每个模型/数据集内部的三方法固定同服务器、同卡、同 NUMA：Qwen 为 6 号卡/NUMA4；GLM 原服务器为 5 号卡，新服务器为 7 号卡，均绑定 NUMA2。只计算同一对照组内的速度比。其他卡及并行模型的资源占用见设备快照，不视为整机独占。',
            'Cache-Offload Eager 与 LatchMoE 使用相同缓存策略、容量和异步加载，缓存历史可能不同。Native 是不同搬运组织的系统参考；GLM Native 预取池比 LatchMoE 动态专家槽多 72 MiB。',
            '上述速度比反映 Prefill 与 Decode 两阶段的整体执行差异：LatchMoE 使用新增 Prefill 批次图和既有 Decode 图，Eager 全程 eager。新增 Prefill 批次图的独立增量收益，需要保持 Decode 路径一致的另项消融；本 Q1 不承担该归因。',
            '启动、编译和新增图捕获不计入请求耗时；吞吐分母为整批生成阶段墙钟时间，包含请求间记录进度的开销。']
    lines+=['','缓存与搬运审计（同策略不表示逐步缓存历史相同）：','',
            '| 模型 | 数据集 | LatchMoE misses | Eager misses | LatchMoE H2D(GiB) | Eager H2D(GiB) | 历史摘要相同 |',
            '|---|---|---:|---:|---:|---:|---|']
    for c in result['comparisons']:
        a=c.get('cache_audit')
        if a:
            lines.append(f"| {c['model']} | {c['dataset']} | {a['latchmoe_misses']} | {a['eager_misses']} | {a['latchmoe_h2d_bytes']/2**30:.3f} | {a['eager_h2d_bytes']/2**30:.3f} | {'是' if a['same_history_digest'] else '否'} |")
    if result.get('pending_quality_checks'):
        lines+=['','尚待完成的质量检查：'+ '；'.join(result['pending_quality_checks'])+'。']
    if result['errors']:
        lines+=['','待解决项目：','', '```json',json.dumps(result['errors'],ensure_ascii=False,indent=2),'```']
    (root/'RESULTS.zh.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    args=p.parse_args();r=analyze(args.root);write(args.root,r)
    print(json.dumps({k:r[k] for k in ('complete','valid','missing','errors','pending_quality_checks')},ensure_ascii=False))
