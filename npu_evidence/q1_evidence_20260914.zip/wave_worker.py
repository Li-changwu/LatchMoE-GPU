import os
from rebuild_worker import EvidenceWorkerExtension

ARENA = None
POINTERS = {}
BASE_CALLS = []
INSTALLED = False

class WaveWorkerExtension(EvidenceWorkerExtension):
    def get_rebuild_evidence(self,reset=False):
        global ARENA,POINTERS,INSTALLED
        from vllm_moe_offload_ascend.moe_offload.runtime import get_moe_offload_runtime
        from vllm_ascend.ops.fused_moe.moe_comm_method import MoECommMethod
        runtime = get_moe_offload_runtime()
        if reset:
            if INSTALLED:
                raise RuntimeError('Only one setup per worker')
            arm = os.environ['WAVE_ARM']
            original = MoECommMethod._run_b2_main_cache_streaming
            if arm!='baseline':
                import torch
                from wave_executor import Arena
                # vLLM captures existing inference tensors in InferenceMode;
                # the setup RPC itself does not automatically enter that mode.
                with torch.inference_mode():
                    ARENA = Arena(runtime,arm)
            def run(comm,**kwargs):
                inp = kwargs['fused_experts_input']
                BASE_CALLS.append((int(inp.offload.layer_id),int(inp.hidden_states.shape[0])))
                if ARENA is None:
                    return original(comm,**kwargs)
                from wave_executor import run_indexed
                return run_indexed(comm,ARENA,original,**kwargs)
            MoECommMethod._run_b2_main_cache_streaming = run
            POINTERS = {i:(b.w13_slots.data_ptr(),b.w2_slots.data_ptr(),runtime._log2phy_buffers[i].data_ptr())
                        for i,b in runtime._slot_banks.items()}
            INSTALLED = True
        result = super().get_rebuild_evidence(reset=reset)
        if any(POINTERS[i]!=(b.w13_slots.data_ptr(),b.w2_slots.data_ptr(),runtime._log2phy_buffers[i].data_ptr())
               for i,b in runtime._slot_banks.items()):
            raise AssertionError('Expert bank or Decode mapping address changed')
        result['wave_reuse'] = {'arm':os.environ['WAVE_ARM'],'layer_tokens':BASE_CALLS,
            'decode_addresses_unchanged':True,'verification':os.environ.get('WAVE_VERIFY')=='1',
            'arena':ARENA.evidence() if ARENA else None}
        return result
